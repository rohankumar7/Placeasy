<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="./student/form_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.css"/>
    <script src="./../js/wow.min.js"></script>
  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      body{
        font-family: 'Montserrat';
      }
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9face6;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
      .back{
        background-image:linear-gradient(to right, rgb(1,1,1,0.6), rgb(116,235,213,0.8)),url("./img/1.jpg");
        background-size: cover;
        background-position: center center;
        height: 550px;
        margin-top: -20px;
      }
      .form-submit {
  width: 50%;
  border-radius: 5px;
  -moz-border-radius: 5px;
  -webkit-border-radius: 5px;
  -o-border-radius: 5px;
  -ms-border-radius: 5px;
  padding: 10px 20px;
  font-size: 14px;
  font-weight: bold;
  color: #fff;
  text-transform: uppercase;
  border: none;
  background-image: -moz-linear-gradient(to left, #74ebd5, #9face6);
  background-image: -ms-linear-gradient(to left, #74ebd5, #9face6);
  background-image: -o-linear-gradient(to left, #74ebd5, #9face6);
  background-image: -webkit-linear-gradient(to left, #74ebd5, #9face6);
  background-image: linear-gradient(to left, #74ebd5, #9face6); }
    @media only screen and (max-width: 576px) {
      .image{
        display: none;
      }
      .off{
        margin-bottom: 20px;
      }
            .form-submit {
  width: 100%;
  border-radius: 5px;
  -moz-border-radius: 5px;
  -webkit-border-radius: 5px;
  -o-border-radius: 5px;
  -ms-border-radius: 5px;
  padding: 10px 20px;
  font-size: 14px;
  font-weight: bold;
  color: #fff;
  text-transform: uppercase;
  border: none;
  background-image: -moz-linear-gradient(to left, #74ebd5, #9face6);
  background-image: -ms-linear-gradient(to left, #74ebd5, #9face6);
  background-image: -o-linear-gradient(to left, #74ebd5, #9face6);
  background-image: -webkit-linear-gradient(to left, #74ebd5, #9face6);
  background-image: linear-gradient(to left, #74ebd5, #9face6); }
}
 html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}
  .contact{
        background-image:linear-gradient(to right, rgb(1,1,1,0.9), rgb(1,1,1,0.8)),url("./img/5.jpg");
        background-size: cover;
        background-position: center center;
        padding: 30px 20px;
  }
    .info{
      color:#999;
      font-weight: bold;
    }
    </style>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm p-2 mb-3 bg-white">
  <div class="container">
    <a class="navbar-brand" href="https://sdmcet.ac.in/"><img src="SDME-logo.png" alt="" class="img-fluid" width="250px"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav ml-auto">
        <a class="nav-item nav-link info" href="./admin/login.php">Admin Login</a>
    </div>
  </div>
</div>
</div>
</nav>
<div class="back">
  <div class="container">
    <div class="row align-items-center" style="padding: 100px 50px">
      <div class="col-md-8 col-12 col-sm-6">
                <p style="font-weight: bold;font-size: 60px;color:#fff">Placeasy</p><br><p style="margin-top: -55px;color: #fff;font-weight: bold;">An automated solution for placement acivities mangement and report generation.</p>
          <a href="./student/login.php"><button class="btn btn-info"><span style="font-weight: bold;">Login</span></button></a>
          <a href="./student/register_form.php"><button class="btn btn-info"><span style="font-weight: bold;">Register</span></button></a>
      </div>
      <div class="col-md-4 col-12 col-sm-6">
        <img src="./img/main.svg" alt="" class="img-fluid image" width="350px">
      </div>
    </div>
  </div>
</div>
<div class="contact">
  <h2 style="text-align: center;color: #f62459">Contact</h2>
  <br>
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-sm-6 col-12">
          <div class="container">
            <div class="row">
              <div class="col-md-1">
                <i class="fas fa-map-marker-alt info" style="color: #ebebeb"></i>                
              </div>
              <div class="col-md-11">
                <h4 class="info" style="color: #ebebeb">Address</h4>
                <br>
                <p style="line-height: 2px" class="info">SDM College of Engineering and Technology,</p>
                <p style="line-height: 2px" class="info">Dhavalagiri Dharwad</p>
                <p style="line-height: 2px" class="info">580-002</p>
                <br>
              </div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-md-1">
                <i class="fas fa-phone info" style="color: #ebebeb"></i>
              </div>
              <div class="col-md-11">
                <h4 class="info" style="color: #ebebeb">Contact Number</h4>
                <br>
                <p style="line-height: 2px" class="info">+91 9685741425</p>
                <p style="line-height: 2px" class="info">+91 6541358575</p>
                <br>
              </div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-md-1">
                <i class="far fa-envelope info" style="color: #ebebeb"></i>
              </div>
              <div class="col-md-11">
                <h4 class="info" style="color: #ebebeb">Email Address</h4>
                <br>
                <p style="line-height: 2px" class="info">example1@gmail.com</p>
                <p style="line-height: 2px" class="info">example2.@gmail.com</p>
                <br>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-6 col-12">
          <form>
            <div class="form-group">
              <input type="text" name="name" placeholder="Full Name" required class="form-control form-input" style="background-color: transparent;"> 
            </div>
            <div class="form-group">
              <input type="email" name="email" placeholder="Email Address" required class="form-control form-input" style="background-color: transparent;">
            </div>
            <div class="form-group">
              <textarea rows="5" placeholder="Write us a message" class="form-control form-input" style="background-color: transparent;"></textarea>
            </div>
            <div class="form-group">
              <input type="submit" name="query" class="form-submit" value="send message">
            </div>
          </form>          
        </div>
      </div>
    </div>
</div>
      <footer style="background-color: #111;padding: 20px">
        <h2 style="color: #999;font-weight: bolder;text-align: center;">Placeasy</h2>
        <p style="color: #777;text-align: center;font-weight: bold;">&copy; All right reserved.</p>
      </footer>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.js"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>