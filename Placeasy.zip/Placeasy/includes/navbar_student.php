<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light shadow-sm p-2 mb-3 bg-white">
  <div class="container">
    <a class="navbar-brand" href="#"><span style="color: #f62459;font-weight: bold;">Placeasy</span></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav ml-auto">
              <a class="nav-item nav-link drop-notification info" href="" data-toggle="modal" data-target="#exampleModalScrollable">notification
                <i class="fas fa-bell" style="font-size: 15px">
                <span class="badge badge-pill badge-danger count" style="border-radius: 10px;padding: 3px 6px;"></span>
                </i>
              </a>
        <?php 
          if($_SESSION['category']=="Diploma"){?>
                    <a class="nav-item nav-link info" href="my_account_diploma.php">My Account</a>
        <?php } else{ ?>
        <a class="nav-item nav-link info" href="my_account.php">My Account</a>
      <?php } ?>
        <li class="nav-item dropdown">
        <a class="nav-link info dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Manage Account
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <?php 
              if($_SESSION['category']=="Diploma"){?>
          <a class="dropdown-item info" href="academic_details_diploma.php">Add Academic</a>
          <a class="dropdown-item info" href="off_campus.php">Add OffCampus</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item info" href="update_personal_details.php">Edit personal info</a>
          <a class="dropdown-item info" href="update_academic_details_diploma.php">Edit Academic</a>      
              <?php } else {?>
          <a class="dropdown-item info" href="academic_details.php">Add Academic</a>
          <a class="dropdown-item info" href="off_campus.php">Add OffCampus</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item info" href="update_personal_details.php">Edit personal info</a>
          <a class="dropdown-item info" href="update_academic_details.php">Edit Academic</a>
          <?php } ?>
        </div>
      </li>
        <a class="nav-item nav-link info" href="view_company.php">View Company</a>
        <a class="nav-item nav-link info" href="history.php">History</a>
        <a class="nav-item nav-link info" href="change_password.php">Change Password</a>
        <a class="nav-item nav-link info" href="logout.php">Logout</a>
      </div>
    </div>
  </div>
</nav>
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #ebebeb">
        <h5 class="modal-title info" id="exampleModalScrollableTitle">Notifications</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container">
          <div class="drlist" style="list-style-type: none;"></div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
$(document).ready(function(){
 
 function load_unseen_notification(view = '')
 {
  $.ajax({
   url:"fetch_notification.php",
   method:"POST",
   data:{view:view},
   dataType:"json",
   success:function(data)
   {
    $('.drlist').html(data.notification);
    if(data.unseen_notification > 0)
    {
     $('.count').html(data.unseen_notification);
    }
   }
  });
 }
 
 load_unseen_notification();
 
 $(document).on('click', '.drop-notification', function(){
  $('.count').html('');
  load_unseen_notification('yes');
 });

 setInterval(function(){ 
  load_unseen_notification(); 
 }, 2000);
 
});
</script>