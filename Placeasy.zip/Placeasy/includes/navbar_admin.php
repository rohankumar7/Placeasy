<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light shadow-sm p-2 mb-3 bg-white">
  <div class="container">
    <a class="navbar-brand" href="#"><span style="color: #f62459;font-weight: bold;">Placeasy</span></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
        <a class="nav-link info dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Manage Company
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item info" href="add_company.php">Add Company</a>
          <a class="dropdown-item info" href="add_branch.php">Add Branch</a>
          <a class="dropdown-item info" href="add_job.php">Add Job</a>
          <a class="dropdown-item info" href="add_round.php">Add Round</a>
        </div>
      </li>
        <a class="nav-item nav-link info" href="eligible_list.php">Conduct Round</a>
        <a class="nav-item nav-link info" href="print_report.php">Print Report</a>
      <li class="nav-item dropdown">
        <a class="nav-link info dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Account
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="nav-item nav-link info" href="change_password.php">Change Password</a>
          <a class="nav-item nav-link info" href="logout.php">Logout</a>
        </div>
      </li>
      </div>
    </div>
  </div>
</nav>