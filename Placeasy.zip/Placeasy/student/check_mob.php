<?php 
require_once("../includes/config.php");
// code admin email availablity
if(!empty($_POST["mobnumber"])) {
$mobnumber= $_POST["mobnumber"];
$sql ="SELECT student_phoneno FROM student WHERE student_phoneno='$mobnumber'";
$results = mysqli_query($conn,$sql);
$count = mysqli_num_rows($results);
if($count>0)
{
echo "<span class='error'> Number already exists .</span>";
 echo "<script>$('#inp').prop('disabled',true);</script>";
} else{
	
	echo "<span class='success'> Number available for Registration.</span>";
 echo "<script>$('#inp').prop('disabled',false);</script>";
}
}
?>
