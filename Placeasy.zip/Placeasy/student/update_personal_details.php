<?php 
include "../includes/config.php";
error_reporting(0);
session_start();
if(strlen($_SESSION['usn'])== ""){
  header("Location:login.php");
}else{
    if(isset($_POST['submit'])){
      $usn = $_SESSION['usn'];
      $name = $_POST['name'];
      $email = $_POST['email'];
      $placement_year = $_POST['placement_year'];
      $mobnumber = $_POST['mobile'];
      $sql = "UPDATE student SET 
      student_name='$name',
      email='$email',
      placement_year='$placement_year',
      student_phoneno='$mobnumber'
      where usn='$usn'";
      $result = mysqli_query($conn,$sql);
      if ($result) {
        $succ="Successfully updated personal details!"; 
      }
      else{
        $err="Something went wrong, please try again!";
      }
  }    
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="form_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9face6;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>
    <title>Update Account</title>  
  </head>
  <body>
        <div id="overlay">
      <div class="loader"></div>
    </div>
<?php include("../includes/navbar_student.php"); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-12 col-sm-12  offset-md-3 form-panel wow fadeInLeft animated">
          <!--<a href="#" class="back-btn"><i class="fas fa-arrow-left"></i></a>-->
          <h2 class="form-header"><i class="far fa-user"></i> Update your account.</h2>
            <form method="post">
              <div class="row">
                <div class="col-sm-12 col-md-12 col-12">
                  <p class="info">Please enter personal details.</p>
                    <?php
                        if ($err) {?>
                          <div class="error wow fadeInLeft animated"><?php echo htmlentities($err); ?></div>
                    <?php } else if($succ) { ?>
                          <div class="success wow fadeInLeft animated"><?php echo htmlentities($succ); ?></div>
                    <?php }
                    ?>
                    <?php 
                        $usn = $_SESSION['usn'];
                        $sql = "SELECT * from student where usn='$usn'";
                        $res = mysqli_query($conn,$sql);
                        while($data = mysqli_fetch_assoc($res)){?>

                  <div class="form-row">
                    <div class="form-group col-12">
                      <input type="text" class="form-control form-input special" id="fullname" name="name" placeholder="Full Name" value="<?php echo htmlentities($data['student_name']); ?>" required/>
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="form-group col-sm-6 col-md-6 col-6">
                      <input type="text" class="form-control form-input special" id="usn" name="usn" placeholder="USN" value="<?php echo htmlentities($data['usn']); ?>" required disabled>
                    </div>
                    <div class="form-group col-sm-6 col-md-6 col-6">
                       <select  name="branch" class="form-control form-select" autocomplete="off"  required disabled/>
                      <?php
                      $sql1 = "SELECT b.branch_name,b.branch_id from branch as b,student as s where b.branch_id = S.branch_id AND s.usn = '$usn'";
                      $resu=mysqli_query($conn,$sql1);
                      while($d = mysqli_fetch_assoc($resu)){?>
                      <option value="<?php echo htmlentities($d['branch_id']); ?>"><?php echo htmlentities($d['branch_name']);?></option>
                      <?php } ?>
                      </select>     
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="form-group col-12">
                      <input type="email" class="form-control form-input special" id="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" name="email" placeholder="Email Address" value="<?php echo htmlentities($data['email']); ?>" required/>
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="form-group col-6 col-sm-6 col-md-6">
                      <input type="text" class="form-control form-input special" id="placement_year" name="placement_year" placeholder="Placement Year" value="<?php echo htmlentities($data['placement_year']); ?>" required/>
                    </div>
                    <div class="form-group col-6 col-sm-6 col-md-6">
                      <input type="number" class="form-control form-input special" id="mob" pattern="\d{10}" title="Please enter valid mobile number" name="mobile" placeholder="Mobile Number" value="<?php echo htmlentities($data['student_phoneno']); ?>" required/>
                    </div>
                  </div>
                  <button type="submit" name="submit" id="inp" class="btn btn-primary form-submit">update</button>
                  <?php } ?>
                </div>
              </div> 
            </form>
        </div>
      </div>
    </div>
    <div style="margin-top: 50px;"></div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>