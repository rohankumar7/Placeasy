<?php
include "../includes/config.php";
session_start();
if(isset($_POST["view"]))
{
 $usn = $_SESSION['usn'];
 if($_POST["view"] != '')
 {
  $update_query = "UPDATE notification SET status=1 WHERE status=0 and usn = '$usn'";
  mysqli_query($conn, $update_query);
 }
 $query = "SELECT * FROM notification WHERE usn = '$usn' order by creation_date desc";
 $result = mysqli_query($conn, $query);
 $output = '';
 
 if(mysqli_num_rows($result) > 0)
 {
  while($row = mysqli_fetch_assoc($result))
  {
   $output .= '
   <li>
     <b style="color:red;">'.$row['company_name'].'</b><br/>
     <small style="color:#999"><b>'.$row['notification_text'].'</b></small><br/>
     <small style="color:#999">time : '.$row['creation_date'].'</small>
  </li>
  <hr>
   ';
  }
 }
 else
 {
  $output .= '<li class="info">No Notification Found</li>';
 }
 
 $query_1 = "SELECT * FROM notification WHERE usn = '$usn' and status=0";
 $result_1 = mysqli_query($conn, $query_1);
 $count = mysqli_num_rows($result_1);
 $data = array(
  'notification'   => $output,
  'unseen_notification' => $count
 );
 echo json_encode($data);
}
?>