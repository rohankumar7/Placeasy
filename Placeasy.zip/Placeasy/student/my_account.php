<?php
include "../includes/config.php";
session_start();
error_reporting(0);
if(strlen($_SESSION['usn'])== ""){
  header("Location:login.php");
}
else{
$usn = $_SESSION['usn'];
$sql = "SELECT * from student_academic where usn='$usn'";
$res = mysqli_query($conn,$sql);
$count = mysqli_num_rows($res);
if ($count == 0) {
   $msg = "Please enter your academic details.";
 } 
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="form_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9face6;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }
      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>

    <title>My Account</title>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
    <?php include "../includes/navbar_student.php"; ?>
    <div class="container">
      <div class="row">  
        <div class="col-md-10 col-12 col-sm-12  offset-md-1 form-panel">
            <form>
              <?php 
                        $usn = $_SESSION['usn'];
                        $sql = "SELECT branch.branch_name from student,branch where student.usn='$usn'and branch.branch_id = student.branch_id";
                        $result = mysqli_query($conn, $sql);
                        $d1 =  mysqli_fetch_assoc($result);
                        $branch_name = $d1['branch_name'];
                        $sql = "SELECT * from student where usn='$usn'";
                        $mul = 10;
                        $res = mysqli_query($conn,$sql);
                        while($data = mysqli_fetch_assoc($res)){?>
              <div class="row">
                <div class="col-sm-12 col-md-6 col-12 wow fadeInLeft animated">
                  <p class="info"><i class="fas fa-user"></i> Personal Details</p>
                  <div class="row">
                    <div class="col-sm-6 col-md-6 col-6">
                      <p class="info purple">Name</p>
                      <p class="info"><?php echo htmlentities($data['student_name']);?></p>
                    </div>
                    <div class="col-sm-6 col-md-6 col-6">
                      <p class="info purple">Gender</p>
                      <p class="info"><?php echo htmlentities($data['gender']);?></p>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-sm-6 col-md-6 col-6">
                      <p class="info purple">USN</p>
                      <p class="info"><?php echo htmlentities($data['usn']);?></p>
                    </div>
                    <div class="col-sm-6 col-md-6 col-6">
                       <p class="info purple">Branch</p>
                       <p class="info"><?php echo htmlentities($branch_name);?></p>   
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-12">
                      <p class="info purple">Email<span></span></p>
                      <p class="info"><?php echo htmlentities($data['email']);?></p>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-6 col-sm-6 col-md-6">
                      <p class="info purple">Placement year</p>
                      <p class="info"><?php echo htmlentities($data['placement_year']);?></p>
                    </div>
                    <div class="col-6 col-sm-6 col-md-6">
                     <p class="info purple">Mobile</p>
                     <p class="info"><?php echo htmlentities($data['student_phoneno']);?></p>
                    </div>
                  </div>
                  <?php } ?>
                  
                </div>
                <div class="col-sm-12 col-md-6 col-12 wow fadeInLeft animated">
                    
                   <p class="info"><i class="fas fa-university"></i> Academic Details</p>
                   <?php
                      if ($msg) {?>
                        <div class="error"><?php echo htmlentities($msg); ?><br>goto :<a href="academic_details.php"><span style="color: #777"> Manage Account > Add academic</span></a></div>
                  <?php } ?>
                    <?php 
                        $usn = $_SESSION['usn'];
                        $sql1 = "SELECT * from student_academic where usn='$usn'";
                        $res1 = mysqli_query($conn,$sql1);
                        while($data1 = mysqli_fetch_assoc($res1)){
                            $bac = $data1['backlog'];
                        ?>
                    <div class="row">
                      <div class="col-md-4 col-sm-4 col-4">
                        <p class="info purple">10th board</p>
                        <p class="info"><?php echo htmlentities($data1['marks_10']);?>%</p>
                      </div>

                      <div class="col-md-4 col-sm-4 col-4">
                        <p class="info purple">12th Board</p>
                        <p class="info"><?php echo htmlentities($data1['marks_12']);?>%</p>
                      </div>
                      <div class="col-md-4 col-sm-4 col-4">
                        <p class="info purple">CGPA</p>
                        <p class="info"><?php echo round(htmlentities($data1['cgpa']),2);?> cgpa</p>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-12">
                        <p class="info">semester 1</p>
                        <div class="progress">
                          <div class="progress-bar bg-info" style="width:<?php echo $mul*$data1['sem_1'];?>%;font-weight:bold;"><?php echo htmlentities($data1['sem_1']);?></div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6 col-12">
                        <p class="info">semester 2</p>
                        <div class="progress">
                          <div class="progress-bar bg-info" style="width:<?php echo $mul*$data1['sem_2'];?>%;font-weight:bold;"><?php echo htmlentities($data1['sem_2']);?></div>
                        </div>
                      </div>
                      <div class="col-md-6 col-12">
                        <p class="info">semester 3</p>
                        <div class="progress">
                          <div class="progress-bar bg-info" style="width:<?php echo $mul*$data1['sem_3'];?>%;font-weight:bold;"><?php echo htmlentities($data1['sem_3']);?></div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12">
                        <p class="info">semester 4</p>
                        <div class="progress">
                          <div class="progress-bar bg-info" style="width:<?php echo $mul*$data1['sem_4'];?>%;font-weight:bold;"><?php echo htmlentities($data1['sem_4']);?></div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6 col-12">
                        <p class="info">semester 5</p>
                        <div class="progress">
                          <div class="progress-bar bg-info" style="width:<?php echo $mul*$data1['sem_5'];?>%;font-weight: bold;"><?php echo htmlentities($data1['sem_5']);?></div>
                        </div>
                      </div>
                      <div class="col-md-6 col-12">
                        <p class="info">semester 6</p>
                        <div class="progress">
                          <div class="progress-bar bg-info" style="width:<?php echo $mul*$data1['sem_6'];?>%;font-weight:bold;"><?php echo htmlentities($data1['sem_6']);?></div>
                        </div>
                      </div>
                     </div>
                     <div class="row">
                      <div class="col-12">
                        <p class="info">semester 7</p>
                        <div class="progress">
                          <div class="progress-bar bg-info" style="width:<?php echo $mul*$data1['sem_7'];?>%;font-weight:bold;"><?php echo htmlentities($data1['sem_7']);?></div>
                        </div>
                      </div>
                     </div>
                     <div class="row">
                      <div class="col-12">
                        <p class="info">semester 8</p>
                        <div class="progress">
                          <div class="progress-bar bg-info" style="width:<?php echo $mul*$data1['sem_8'];?>%;font-weight:bold;"><?php echo htmlentities($data1['sem_8']);?></div>
                        </div>
                      </div>
                     </div>  
                      <div class="col-12" style="margin-top: 20px">
                        <p class="info">You are having <?php echo $bac;?> backlogs.</p>
                      </div>
                    </div> 
                    </div> 
                    </div>  
              </div>
            </div>
            <?php } ?>    
          </form>
        </div>
      </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>
