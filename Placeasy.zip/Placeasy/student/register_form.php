<?php
 date_default_timezone_set("Asia/Calcutta"); 
include "../includes/config.php";
$y = date('y');
$y1 = date('y') +1;
$year = "20".$y."-"."20".$y1;
error_reporting(0);
if(isset($_POST['register'])){
  $usn = strtoupper($_POST['usn']);
  $s_name = ucwords($_POST['name']);
  $email = $_POST['email'];
  $password = $_POST['password'];
  $branch = $_POST['branch'];
  $placement_year = $_POST['placement_year'];
  $mobnumber = $_POST['mobile'];
  $cat = $_POST['category'];
  $gen = $_POST['gender'];
  $sql = "INSERT INTO student (usn,student_name,gender,email,password,branch_id,placement_year,student_phoneno,category) VALUES ('$usn','$s_name','$gen','$email','$password','$branch','$placement_year','$mobnumber','$cat')";
  $result = mysqli_query($conn,$sql);
  if ($result) {
    $succ="Successfully registered, now you can login !"; 
  }
  else{
    $err="USN already takens,contact adminstrator !";
  }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="form_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9face6;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>
    <title>Create Account</title>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-12 col-sm-12  offset-md-3 form-panel wow fadeInLeft animated">
          <!--<a href="#" class="back-btn"><i class="fas fa-arrow-left"></i></a>-->
          <h2 class="form-header"><i class="far fa-user"></i> Create your account.</h2>
            <form method="post">
              <div class="row">
                <div class="col-sm-12 col-md-12 col-12">
                  <div class="or">
                    <hr class="bar">
                    <span class="info pad">Please enter personal details</span>
                    <hr class="bar">
                  </div>

                  <?php
                    if ($err) {?>
                          <div class="error wow fadeInLeft animated"><?php echo htmlentities($err); ?></div>
                  <?php } else if($succ) { ?>
                          <div class="success wow fadeInLeft animated"><?php echo htmlentities($succ); ?></div>
                  <?php }
                    ?>
                  <div class="form-row">
                    <div class="form-group col-12">
                      <input type="text" class="form-control form-input special" title="must contain only characters." id="fullname" name="name" placeholder="Full Name" required/>
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="form-group col-sm-6 col-md-6 col-6">
                      <input type="text" class="form-control form-input special" id="usn" 
                      pattern="^[(2sd|2SD)]{3}\d{2}[(cs|CS|is|IS|ec|EC|ee|EE|me|ME|cv|CV|ch|CH)]{2,}\d{3}$" title="USN must start with 2sd or 2SD" name="usn" placeholder="USN" required/>
                      <span id="usn_err" class="error"></span>
                    </div>
                    <div class="form-group col-sm-6 col-md-6 col-6">
                      <select id="branch" name="branch" class="form-control form-select" autocomplete="off"  required/>
                      <option value="">Branch...</option>
                      <?php
                      $sql = "SELECT branch_name,branch_id from branch";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['branch_id']); ?>"><?php echo htmlentities($data['branch_name']);?></option>
                      <?php } ?>
                      </select>
                      <span id="branch_err" class="error"></span>   
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="form-check">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="category" value="Engineering" required><span class="info" required>Engineering</span>
                      </label>
                    </div>
                    <div class="form-check" style="margin-left: 20px">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="category" value="Diploma"><span class="info">Diploma</span>
                      </label>
                    </div>
                  </div>

                  <div class="form-row" style="margin-top: 10px">
                    <div class="form-group col-12">
                      <input type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" onBlur="check_email()" class="form-control form-input special" id="email" name="email" placeholder="Email Address" required/>
                      <div id="email_error"></div>
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="form-group col-12">
                      <input type="password" class="form-control form-input special" id="pass" name="password" placeholder="Password" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required/>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-check">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" required name="gender" value="female"><span class="info">Female</span>
                      </label>
                    </div>
                    <div class="form-check" style="margin-left: 20px">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="gender" value="male"><span class="info">Male</span>
                      </label>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-6 col-sm-6 col-md-6">
                      <input type="text" class="form-control form-input special" value="<?php echo ($year);?>" id="placement_year" name="placement_year" placeholder="Placement Year" required/>
                    </div>
                    <div class="form-group col-6 col-sm-6 col-md-6">
                      <input type="text" pattern="\d{10}" title="Please enter valid mobile number" class="form-control form-input special" id="mob" name="mobile" placeholder="Mobile Number" onBlur="check_mob()" required/>
                      <div id="mob_error"></div>
                    </div>
                  </div>
                  <button type="register" name="register" id="inp" class="btn btn-primary form-submit">create account</button>
                    <p class="login-info" style="text-align: center;margin-top:15px ">Already have an account ? <a href="login.php">click here</a></p>
                </div>
              </div> 
            </form>
        </div>
      </div>
    </div>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>

<script type="text/javascript">
$(document).ready(function(){

    $('#usn_err').hide();
    $('#usn').focusout(function(){
        usn_validate();
    });
    function usn_validate(){
      var usn = $('#usn').val();
      var year = parseInt(usn.charAt(3) + usn.charAt(4));
      var current_year = parseInt(new Date().getFullYear().toString().substr(-2)-2);
      if(year <= current_year){
        $('#usn_err').html("");
        $('#pass_err').hide();
        $('#inp').prop('disabled',false);
      }
      else{
        $('#usn_err').html("USN not allowed.");
        $('#usn_err').show();
        $('#inp').prop('disabled',true);
      }
    } 
  });
</script>
<script type="text/javascript">
$(document).ready(function(){

    $('#branch_err').hide();
    $('#branch').focusout(function(){
        branch_validate();
    });
    function branch_validate(){
      var branch = $('#branch :selected').text();
      var usn = $('#usn').val();
      var br = usn.charAt(5) + usn.charAt(6);
      var data = {
                CS : "CS Engineering",
                cs : "CS Engineering",
                IS : "IS Engineering",
                is : "IS Engineering",
                CV : "Civil Engineering",
                cv : "Civil Engineering",
                CH : "Chemical Engineering",
                cs : "Chemical Engineering",
                EC : "E&C Engineering",
                ec : "E&C Engineering",
                EE : "E&E Engineering",
                ee : "E&E Engineering",
                ME : "CS Engineering",
                me : "Mechanical Engineering"
      };
      if(data[br]==branch){
        $('#branch_err').html("");
        $('#branch_err').hide();
        $('#inp').prop('disabled',false);
      }else{
        $('#branch_err').html("Branch not matched usn.");
        $('#branch_err').show();
        $('#inp').prop('disabled',true);
      }
    } 
  });
</script>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>
<script>
function check_email() {

$("#loaderIcon").show();
jQuery.ajax({
url: "check_email.php",
data:'emailid='+$("#email").val(),
type: "POST",
success:function(data){
$("#email_error").html(data);
},
error:function (){}
});
}
</script>
<script>
function check_mob() {

$("#loaderIcon").show();
jQuery.ajax({
url: "check_mob.php",
data:'mobnumber='+$("#mob").val(),
type: "POST",
success:function(data){
$("#mob_error").html(data);
},
error:function (){}
});
}
</script>
