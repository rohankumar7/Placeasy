<?php
include "../includes/config.php";
error_reporting(0);
session_start();
if(strlen($_SESSION['usn']) == ""){
  header("Location: login.php");
  }else{
if(isset($_POST['change'])){
  $usn = $_SESSION['usn'];
  $password = $_POST['password'];
  $newpassword = $_POST['newpassword'];
  $sql = "SELECT password FROM student WHERE usn='$usn' and password='$password'";
  $result = mysqli_query($conn,$sql);
  $checkresult = mysqli_num_rows($result);
  if($checkresult>0){
    $sql = "UPDATE student SET password='$newpassword' where usn='$usn'";
    mysqli_query($conn,$sql);
    $succ = "Your password successfully changed!";
  }
  else{
    $err = "Your current password is wrong!";
  }
}
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="form_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
  <script>
     new WOW().init();
  </script>
    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9face6;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>

    <title>Change Password</title>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
    <?php include "../includes/navbar_student.php"; ?>
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-12 col-sm-12 offset-md-3 form-panel wow fadeInLeft animated">
          <h2 class="form-header"><i class="fas fa-unlock-alt"></i> change password</h2>
            <form method="post">
              <div class="form-group">
                  <?php
                    if ($err) {?>
                          <div class="error wow fadeInLeft animated"><?php echo htmlentities($err); ?></div>
                  <?php } else if($succ) { ?>
                          <div class="success wow fadeInLeft animated"><?php echo htmlentities($succ); ?></div>
                  <?php }
                    ?>
                <input type="password" class="form-control form-input" id="pass" name="password" id="" placeholder="current password" required/>
              </div>
              <div class="form-group">
                <input type="password" class="form-control form-input" 
                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
                title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
                name="newpassword" placeholder="new password" required/>
              </div>
              <div class="form-group">
                <input type="password" class="form-control form-input" 
                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
                title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
                 name="confirmpassword" placeholder="confirm password" required/>
              </div>
              <button type="submit" name="change" class="btn btn-primary form-submit">Submit</button>
            </form>
        </div>
      </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
</script>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>