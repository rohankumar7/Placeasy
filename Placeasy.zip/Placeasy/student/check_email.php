<?php 
require_once("../includes/config.php");
// code admin email availablity
if(!empty($_POST["emailid"])) {
$email= $_POST["emailid"];
$sql ="SELECT email FROM student WHERE email='$email'";
$results = mysqli_query($conn,$sql);
$count = mysqli_num_rows($results);
if($count>0)
{
echo "<span class='error'> Email already exists .</span>";
 echo "<script>$('#inp').prop('disabled',true);</script>";
} else{
	
	echo "<span class='success'> Email available for Registration .</span>";
 echo "<script>$('#inp').prop('disabled',false);</script>";
}
}
?>
