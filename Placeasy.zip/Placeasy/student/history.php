<?php
session_start();
error_reporting(0);
include("../includes/config.php");
if(strlen($_SESSION['usn'])== ""){
  header("Location:login.php");
}
else{
	$usn=$_SESSION['usn'];
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="form_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.css"/>
  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9face6;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }
      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>

    <title>History</title>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
    <?php include "../includes/navbar_student.php"; ?>
<div class="container" style="margin-top: 100px;">
<div class="table-responsive-sm">
          <table id="myTable" class="display">
            <thead>
              <tr>
                <th>Company ID</th>
                <th>Round Name</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $sql= "SELECT DISTINCT c.company_name,r.round_name,s.status from student_eligible_round_details as s,round as r,company as c,student as x where s.usn='$usn' and r.round_id = s.round_id and c.company_id = s.company_id and x.placement_year = c.year;";
              $res=mysqli_query($conn,$sql);
              $cnt=1;
              while($data = mysqli_fetch_assoc($res)){?>
              <tr>
                <td><?php echo htmlentities($data['company_name']); ?></td>
                <td><?php echo htmlentities($data['round_name']); ?></td>
                <td><?php if($data['status'] == "passed"){?>
                    <span style="color:lime;font-weight:bold"><?php echo htmlentities($data['status']); ?> <i class="fas fa-check"></i></span>
                    <?php }elseif($data['status'] == "failed") { ?>
                    <span style="font-weight:bold;color:red"><?php echo htmlentities($data['status']); ?> <i class="fas fa-times"></i></span>
                   <?php }else{?>
                    <span style="font-weight:bold;color:orange"><?php echo htmlentities($data['status']); ?> <i class="fas fa-hourglass-end"></i></span>
                  <?php } ?>
                   </td>
              </tr>
            <?php $cnt++; ?>
            <?php } ?>
            </tbody>
          </table>
    </div>
</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.js"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>
<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>