35 <?php
include "../includes/config.php";
session_start();
error_reporting(0);
if(strlen($_SESSION['usn'])== ""){
  header("Location:login.php");
} else{
if(isset($_POST['academic'])){
  $count=6;
  $usn = $_SESSION['usn'];
  $tenth = floatval($_POST['board10']);
  $twelve = floatval($_POST['board12']);
  $sem1 = floatval($_POST['sem1']);
  $sem2 = floatval($_POST['sem2']);
  $sem3 = floatval($_POST['sem3']);
  $sem4 = floatval($_POST['sem4']);
  $sem5 = floatval($_POST['sem5']);
  $sem6 = floatval($_POST['sem6']);
  $sem7 = floatval($_POST['sem7']);
  $sem8 = floatval($_POST['sem8']);
  if($sem7 > 0)
    $count++;
  if($sem8 > 0)
    $count++;
  $backlogs = intval($_POST['backlog']);
  $cgpa = floatval(($sem1+$sem2+$sem3+$sem4+$sem5+$sem6+$sem7+$sem8)/$count);
  $sql = "UPDATE student_academic SET 
  marks_10='$tenth',
  marks_12='$twelve',
  sem_1='$sem1',
  sem_2='$sem2',
  sem_3='$sem3',
  sem_4='$sem4',
  sem_5='$sem5',
  sem_6='$sem6',
  sem_7='$sem7',
  sem_8='$sem8',
  backlog='$backlogs',
  cgpa='$cgpa' WHERE usn='$usn'";
  $result = mysqli_query($conn,$sql);
  if ($result) {
    $succ="Successfully updated academic details!"; 
  }
  else{
    $err="Something went wrong, please try again!";
  }
}
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="form_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
  <script>
     new WOW().init();
  </script>
    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9face6;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>

    <title>Udate Academic</title>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
  <?php include("../includes/navbar_student.php"); ?>
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-12 col-sm-12  offset-md-3 form-panel wow fadeInLeft animated">
            <!--<a href="#" class="back-btn"><i class="fas fa-arrow-left"></i></a>-->
            <h2 class="form-header"><i class="fas fa-university"></i> Update academic details.</h2>
            <p class="error" id="error_msg"></p>
            <p class="error" id="error_msg1"></p>
              <form method="post" id="form">
                <p id="pass_err"></p>
                <div class="row">
                  <div class="col-sm-12 col-md-12 col-12">
                    <?php
                        if ($err) {?>
                          <div class="error wow fadeInLeft animated"><?php echo htmlentities($err); ?></div>
                    <?php } else if($succ) { ?>
                          <div class="success wow fadeInLeft animated"><?php echo htmlentities($succ); ?></div>
                    <?php }
                    ?>
                    <p class="info">Please enter your 10th and 12th board details in percentage.Don't include "%" Ex - 75.6 not 75.6%</p>
                    <?php 
                        $usn = $_SESSION['usn'];
                        $sql = "SELECT * from student_academic where usn='$usn'";
                        $res = mysqli_query($conn,$sql);
                        while($data = mysqli_fetch_assoc($res)){?>

                    <div class="form-row">
                        <div class="form-group col-md-6 col-sm-6 col-6">
                          <input type="text" class="form-control form-input special" id="10board" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="board10" placeholder="10th Board" value="<?php echo htmlentities($data['marks_10']); ?>" required/>
                        </div>

                        <div class="form-group col-md-6 col-sm-6 col-6">
                          <input type="text" class="form-control form-input special" id="12board" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="board12" placeholder="12th Board" value="<?php echo htmlentities($data['marks_12']); ?>" required/>
                        </div>
                    </div>
                    <p class="info">Please enter your correct sementer marks.<br>Ex - 8.5 not 8.5 cgpa</p>
                    <div class="form-row">
                        <div class="form-group col-md-6 col-sm-6 col-6">
                          <input type="text" class="form-control form-input special" id="sem1" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="sem1" placeholder="Sem 1" value="<?php echo htmlentities($data['sem_1']); ?>" required/>
                        </div>

                        <div class="form-group col-md-6 col-sm-6 col-6">
                          <input type="text" class="form-control form-input special" id="sem2" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="sem2" placeholder="Sem 2" value="<?php echo htmlentities($data['sem_2']) ?>" required/>
                        </div>
                      </div>

                    <div class="form-row">
                        <div class="form-group col-12 col-sm-12 col-md-12">
                          <input type="text" class="form-control form-input special" id="sem3" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="sem3" placeholder="Sem 3" value="<?php echo htmlentities($data['sem_3']); ?>" required/>
                        </div>
                      </div>

                       <div class="form-row">
                        <div class="form-group col-4 col-md-4 col-sm-4">
                          <input type="text" class="form-control form-input special" id="sem4" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="sem4" placeholder="Sem 4" value="<?php echo htmlentities($data['sem_4']); ?>" required/>
                        </div>

                        <div class="form-group col-4 col-md-4 col-sm-4">
                          <input type="text" class="form-control form-input special" id="sem5" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="sem5" placeholder="Sem 5" value="<?php echo htmlentities($data['sem_5']); ?>" required/>
                        </div>

                        <div class="form6-group col-4 col-md-4 col-sm-4">
                          <input type="text" class="form-control form-input special" id="sem6" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="sem6" placeholder="Sem 6" value="<?php echo htmlentities($data['sem_6']); ?>" required/>
                        </div>
                      </div>
                       <div class="form-row">
                        <div class="form-group col-6 col-md-6 col-sm-6">
                          <input type="text" class="form-control form-input special" id="sem7" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="sem7" placeholder="Sem 7" value="<?php echo htmlentities($data['sem_7']); ?>" required/>
                        </div>

                        <div class="form-group col-6 col-md-6 col-sm-6">
                          <input type="text" class="form-control form-input special" id="sem8" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="sem8" placeholder="Sem 8" value="<?php echo htmlentities($data['sem_8']); ?>" required/>
                        </div>
                      </div>
                      <div class="form-row" style="margin-bottom: 10px">
                        <p class="info">Enter number of backlogs.</p>
                        <div class="form6-group col-12 col-md-12 col-sm-12">
                          <input type="text" class="form-control form-input special" id="backlog" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." name="backlog" placeholder="Number of backlogs" value="<?php echo htmlentities($data['backlog']); ?>" required/>
                        </div>
                      </div>
                      <button type="submit" name="academic" id="inp" onclick="lenthpass()" class="btn btn-primary form-submit">update</button>
                      <?php } ?>
                  </div>
                </div> 
              </form>
          </div>
        </div>
      </div>
<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $('#error_msg').hide();
    $('#error_msg1').hide();

    $('#sem1').focusout(function(){
        sem1();
    });
    $('#sem2').focusout(function(){
        sem2();
    });
    $('#sem3').focusout(function(){
        sem3();
    });
    $('#sem4').focusout(function(){
        sem4();
    });
    $('#sem5').focusout(function(){
        sem5();
    });
    $('#sem6').focusout(function(){
        sem6();
    });
    $('#sem7').focusout(function(){
        sem7();
    });
    $('#sem8').focusout(function(){
        sem8();
    });
    $('#10board').focusout(function(){
      tenth();
    });
    $('#12board').focusout(function(){
      twelve();
    });

    function sem1(){
      var sem1 = $('#sem1').val();
      sem1 = parseFloat(sem1);
      if(sem1>10 || sem1<=0){
        $('#error_msg').html("cgpa should be >= 0 and <=10");
        $('#error_msg').show();
        $('#inp').prop('disabled',true);
      }
      else{
        $('#error_msg').hide();
        $('#inp').prop('disabled',false);
      }
    }
    function sem2(){
      var sem2 = $('#sem2').val();
      sem2 = parseFloat(sem2);
      if(sem2 > 10.0 || sem2 <= 0){
        $('#error_msg').html("cgpa should be >= 0 and <=10");
        $('#error_msg').show();
        $('#inp').prop('disabled',true);
      }
      else{
        $('#error_msg').hide();
        $('#inp').prop('disabled',false);
      }
    }
    function sem3(){
      var sem3 = $('#sem3').val();
      sem3 = parseFloat(sem3);
      if(sem3 > 10.0 || sem3 <= 0){
        $('#error_msg').html("cgpa should be >= 0 and <=10");
        $('#error_msg').show();
        $('#inp').prop('disabled',true);
      }
      else{
        $('#error_msg').hide();
        $('#inp').prop('disabled',false);
      }
    }
    function sem4(){
      var sem4 = $('#sem4').val();
      sem4 = parseFloat(sem4);
      if(sem4 > 10.0 || sem4 <= 0){
        $('#error_msg').html("cgpa should be >= 0 and <=10");
        $('#error_msg').show();
        $('#inp').prop('disabled',true);
      }
      else{
        $('#error_msg').hide();
        $('#inp').prop('disabled',false);
      }
    }
    function sem5(){
      var sem5 = $('#sem5').val();
      sem5 = parseFloat(sem5);
      if(sem5 > 10.0 || sem5 <= 0){
        $('#error_msg').html("cgpa should be >= 0 and <=10");
        $('#error_msg').show();
        $('#inp').prop('disabled',true);
      }
      else{
        $('#error_msg').hide();
        $('#inp').prop('disabled',false);
      }
    }
    function sem6(){
      var sem6 = $('#sem6').val();
      sem6 = parseFloat(sem6);
      if(sem6 > 10.0 || sem6 <= 0){
        $('#error_msg').html("cgpa should be >= 0 and <=10");
        $('#error_msg').show();
        $('#inp').prop('disabled',true);
      }
      else{
        $('#error_msg').hide();
        $('#inp').prop('disabled',false);
      }
    }
    function sem7(){
      var sem7 = $('#sem7').val();
      sem7 = parseFloat(sem7);
      if(sem7 > 10.0 || sem7 < 0){
        $('#error_msg').html("cgpa should be > 0 and <=10");
        $('#error_msg').show();
        $('#inp').prop('disabled',true);
      }
      else{
        $('#error_msg').hide();
        $('#inp').prop('disabled',false);
      }
    }
    function sem8(){
      var sem8 = $('#sem8').val();
      sem8 = parseFloat(sem8);
      if(sem8 > 10.0 || sem8 < 0){
        $('#error_msg').html("cgpa should be > 0 and <=10");
        $('#error_msg').show();
        $('#inp').prop('disabled',true);
      }
      else{
        $('#error_msg').hide();
        $('#inp').prop('disabled',false);
      }
    }
    function tenth(){
      var tenth = $('#10board').val();
      tenth = parseFloat(tenth);
      if(tenth > 100.0 || tenth < 35.0){
        $('#error_msg1').html("marks should be >= 35 and <=100");
        $('#error_msg1').show();
        $('#inp').prop('disabled',true);
      }
      else{
        $('#error_msg1').hide();
        $('#inp').prop('disabled',false);
      }
    }
    function twelve(){
       var twelve = $('#12board').val();
      twelve = parseFloat(twelve);
      if(twelve > 100.0 || twelve < 35.0){
        $('#error_msg1').html("marks should be >= 35 and <=100");
        $('#error_msg1').show();
        $('#inp').prop('disabled',true);
      }
      else{
        $('#error_msg1').hide();
        $('#inp').prop('disabled',false);
      }     
    }
  });
</script>