<?php  
include "../includes/config.php";
session_start();
error_reporting(0);
if(strlen($_SESSION['username'])== ""){
  header("Location:login.php");
}
else{
  if(isset($_POST['add_job'])){
  $job_id = $_POST['jobid'];
  $company_id=$_POST['cname'];
  $j_name=$_POST['j_name'];
  $vac=$_POST['j_vacancy'];
  $sal=$_POST['j_salary'];
  $sql="INSERT INTO job_details(job_id,company_id,job_name,job_vacancy,job_salary) 
  values ('$job_id','$company_id','$j_name','$vac','$sal')";
  $result=mysqli_query($conn,$sql);
  if ($result) {
    $succ="Successfully added Job!"; 
  }
  else{
    $err="Something went wrong, please try again!";
  }
}
}
?>
<?php
if(!isset($_POST['add_job'])){
  if (isset($_GET['job_id'])) {
    $id = $_GET['job_id'];
    $sql = "DELETE from job_details where job_id='$id'";
    $results = mysqli_query($conn,$sql);
    if($results){
      $succ = "Successfully deleted Job.";
    }
    else{
      $err = "Cannot delete Job. Please try again";
    }
  }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="admin_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.css"/>

  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9733EE;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>
    <title>Admin | Add Job</title>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
        <?php include "../includes/navbar_admin.php"; ?>
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-12 col-sm-12 form-panel wow fadeInLeft animated">
          <!--<a href="#" class="back-btn"><i class="fas fa-arrow-left"></i></a>-->
          <h2 class="form-header"><i class="far fa-user"></i> Add Job Details.</h2>
            <form method="post">
              <div class="row">
                <div class="col-sm-12 col-md-12 col-12">
                  <p class="info">job id : first 3 alphabet of company name followed by 3 digits.<span class="purple"> ex-company name oracle , job id : ora100</span></p>
                  <?php
                    if ($err) {?>
                          <div class="error wow fadeInLeft animated"><?php echo htmlentities($err); ?></div>
                  <?php } else if($succ) { ?>
                          <div class="success wow fadeInLeft animated"><?php echo htmlentities($succ); ?></div>
                  <?php }
                    ?>
                  <div class="form-row">
                     <div class="form-group col-12 col-sm-12 col-md-2">
                      <input type="text" class="form-control form-input special" name="jobid" pattern="[a-zA-z]{3}[0-9]{3,}"
                      title="enter first 3 character of company + 3 numbers ex- Oracle ora100" placeholder="Job ID" required/>
                    </div>
                    <div class="form-group col-sm-12 col-md-3 col-12">
                      <input type="text" class="form-control form-input special" name="j_name" placeholder="Job Name" required/>
                    </div>
                    <div class="form-group col-sm-12 col-md-3 col-12">
                      <select  name="cname" class="form-control form-select" autocomplete="off"  required/>
                      <option value="">Company Name...</option>
                      <?php
                      $sql = "SELECT company_id,company_name,year from company";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['company_id']); ?>"><?php echo htmlentities($data['company_name']);?>-(<?php echo htmlentities($data['year']);?>)</option>
                      <?php } ?>
                      </select>  
                    </div>
                    <div class="form-group col-sm-12 col-md-2 col-12">
                      <input type="text" class="form-control form-input special" name="j_vacancy" pattern="[0-9]{0,}"
                      title="enter number only." placeholder="Vacancy">
                    </div>
                     <div class="form-group col-12 col-sm-12 col-md-2">
                      <input type="text" class="form-control form-input special" name="j_salary" pattern="[0-9]{0,}"
                      title="enter enter number only." placeholder="Salary" required/>
                    </div>
                  </div>
                                      <div class="form-row">
                      <div class="form-group col-12 col-sm-12 col-md-2 offset-md-10">
                  <button type="submit" name="add_job" id="inp" class="btn btn-primary form-submit">Add Job</button>
                    </div>
                    </div>
                </div>
              </div> 
            </form>
        </div>
      </div>
    </div>
<div class="container">
  <hr>
<div class="table-responsive-sm">
          <table id="myTable" class="display">
            <thead>
              <tr>
                <th>No.</th>
                <th>Job Name</th>
                <th>Company Name</th>
                <th>vacancy</th>
                <th>Salary</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php

              $sql = "SELECT j.job_id,j.job_name,c.company_name,j.job_vacancy,j.job_salary,c.year from job_details as j,company as c where j.company_id = c.company_id";
              $res=mysqli_query($conn,$sql);
              $cnt=1;
              while($d = mysqli_fetch_assoc($res)){?>
              <tr>
                <td><?php echo htmlentities($cnt); ?></td>
                <td><?php echo htmlentities($d['job_name']); ?></td>
                <td style="font-weight: bold;"><?php echo htmlentities($d['company_name']); ?><span style="font-weight: normal;">-( <?php echo ($d['year']);?> )</span></td>
                <td><?php echo htmlentities($d['job_vacancy']); ?></td>
                <td><?php echo htmlentities($d['job_salary']); ?></td>
                <td><a style="color: #222" href="edit_job.php?job_id=<?php echo htmlentities($d['job_id'])?>"><i class="fas fa-edit"></i></a><span style="margin-right: 20px"></span><a onclick="return confirm('Do you want to delete');" style="color: #222" href="add_job.php?job_id=<?php echo htmlentities($d['job_id'])?>"><i class="fas fa-trash-alt"></i></a></td>
              </tr>
            <?php $cnt++; ?>
            <?php } ?>
            </tbody>
          </table>
    </div>
</div>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.js"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>
</script>
<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>