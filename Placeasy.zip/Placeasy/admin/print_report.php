<?php  
  include"../includes/config.php";
 ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <link href="SDM_logo.png" rel="icon">
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="admin_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9733EE;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>
    <title>Admin | report generate</title>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
        <?php include "../includes/navbar_admin.php"; ?>
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-12 col-sm-12 form-panel wow fadeInLeft animated" style="margin-top: 80px">
      <div class="row">
        <div class="col-md-12 col-12 col-sm-12 wow fadeInLeft animated " style="margin-bottom: 50px">
          <!--<a href="#" class="back-btn"><i class="fas fa-arrow-left"></i></a>-->
          <h2 class="form-header">placement statistics pdf</h2>
            <form method="post" action="pdf_gen.php">
              <div class="row">
                <div class="col-sm-12 col-md-2 col-12">
                  <label>Select Year</label>
                      <select  name="year" class="form-control form-select" autocomplete="off" required/>
                      <option value="">select year</option>
                      <?php
                      $sql = "SELECT distinct year from placed";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['year']); ?>"><?php echo htmlentities($data['year']);?></option>
                      <?php } ?>
                      </select>
                </div>
                <div class="col-sm-12 col-md-2 col-12">
                  <label>click to download.</label>
                  <button type="submit" name="submitpdf" class="btn btn-primary form-submit">Download</button>
                </div>
              </div> 
            </form>
        </div>
      </div>
      <hr>
          <h2 class="form-header">Finally placed student report.</h2>
            <form method="post" action="export.php">
              <div class="row">
                <div class="col-sm-12 col-md-3 col-12">
                  <label>Select Company</label>
                      <select  name="company" class="form-control form-select" autocomplete="off" />
                      <option value="0">ALL</option>
                      <?php
                      $sql = "SELECT company_name,company_id,year from company";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['company_name']);?>"><?php echo htmlentities($data['company_name']);?>-(<?php echo htmlentities($data['year']);?>)</option>
                      <?php } ?>
                      </select>
                </div>
                <div class="col-sm-12 col-md-3 col-12">
                  <label>Select Branch</label>
                      <select  name="branch" class="form-control form-select" autocomplete="off" />
                      <option value="0">ALL</option>
                      <?php
                      $sql = "SELECT distinct branch_name,branch_id from branch";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['branch_name']);?>"><?php echo htmlentities($data['branch_name']);?></option>
                      <?php } ?>
                      </select>
                </div>
                <div class="col-sm-12 col-md-3 col-12">
                  <label>Select Year</label>
                      <select  name="year" class="form-control form-select" autocomplete="off" />
                      <option value="1">NONE</option>
                      <?php
                      $sql = "SELECT distinct year from company";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['year']); ?>"><?php echo htmlentities($data['year']);?></option>
                      <?php } ?>
                      </select>
                </div>
                <div class="col-sm-12 col-md-3 col-12">
                  <label>click to download.</label>
                  <button type="submit" name="submit" class="btn btn-primary form-submit">Download</button>
                </div>
              </div> 
            </form>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-12 col-sm-12 wow fadeInLeft animated " style="margin-bottom: 50px">
          <hr>
          <h2 class="form-header">Select options to print other placement report.</h2>
          <p class="info">
            <span class="error">Note:</span>
            <br>To get <span class="success">Eligible Students</span> for a particular company Only select "Company Name".
            <ul>
              <li>To filter according to <span class="success">Department wise</span> select "Branch" + "company name".</li>
            </ul>
          </p>
          <p class="info">
            <br>To get <span class="success">Round details</span> for a particular Round Only select "Round".
            <ul>
              <li>To filter according to <span class="success">Company wise</span> select "Company name" + "Round".</li>
              <li>To filter according to <span class="success">Branch wise</span> select "Round" + "Branch".</li>
              <li>To filter according to <span class="success">Year wise</span> select "Round" + "year".</li>
              <li>To filter according to <span class="success">Company and Branch wise</span> select "Company" + "Round" + "Branch".</li>
            </ul>
          </p>
            <form method="post" action="export.php">
              <div class="row">
                <div class="col-sm-12 col-md-3 col-12">
                  <label>Select Company Name</label>
                      <select  name="company" class="form-control form-select" autocomplete="off" />
                      <option value="0">ALL</option>
                      <?php
                      $sql = "SELECT company_name,company_id,year from company";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['company_id']); ?>"><?php echo htmlentities($data['company_name']);?>-(<?php echo htmlentities($data['year']); ?>)</option>
                      <?php } ?>
                      </select>
                </div>
                <div class="col-sm-12 col-md-2 col-12">
                  <label>Select Round</label>
                      <select  name="round" class="form-control form-select" autocomplete="off" />
                      <option value="1">NONE</option>
                      <?php
                      $sql = "SELECT distinct round_name,round_id from round";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['round_id']); ?>"><?php echo htmlentities($data['round_name']);?></option>
                      <?php } ?>
                      </select>
                </div>
                <div class="col-sm-12 col-md-3 col-12">
                  <label>Select Branch</label>
                      <select  name="branch" class="form-control form-select" autocomplete="off" />
                      <option value="0">ALL</option>
                      <?php
                      $sql = "SELECT distinct branch_name,branch_id from branch";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['branch_id']); ?>"><?php echo htmlentities($data['branch_name']);?></option>
                      <?php } ?>
                      </select>
                </div>
                <div class="col-sm-12 col-md-2 col-12">
                  <label>Select Year</label>
                      <select  name="year" class="form-control form-select" autocomplete="off" />
                      <option value="1">NONE</option>
                      <?php
                      $sql = "SELECT distinct year from company";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['year']); ?>"><?php echo htmlentities($data['year']);?></option>
                      <?php } ?>
                      </select>
                </div>
                <div class="col-sm-12 col-md-2 col-12">
                  <label>click to download.</label>
                  <button type="submit" name="submit2" class="btn btn-primary form-submit">Download</button>
                </div>
              </div> 
            </form>
        </div>
      </div>
      <hr>
      <div class="row">
        <div class="col-md-12 col-12 col-sm-12 wow fadeInLeft animated " style="margin-bottom: 50px">
          <!--<a href="#" class="back-btn"><i class="fas fa-arrow-left"></i></a>-->
          <h2 class="form-header">Select options to print number of offers</h2>
          <p class="info">
            <span class="error">Note:</span>
            <br>To get <span class="success">Overall no of offers</span> select "year".
            <ul>
              <li>To filter according to <span class="success">Department wise</span> select "Branch"</li>
            </ul>
          </p>
            <form method="post" action="export.php">
              <div class="row">
                <div class="col-sm-12 col-md-3 col-12">
                  <label>Select Branch</label>
                      <select  name="branch" class="form-control form-select" autocomplete="off" />
                      <option value="0">ALL</option>
                      <?php
                      $sql = "SELECT distinct branch_name,branch_id from branch";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['branch_name']); ?>"><?php echo htmlentities($data['branch_name']);?></option>
                      <?php } ?>
                      </select>
                </div>
                <div class="col-sm-12 col-md-2 col-12">
                  <label>Select Year</label>
                      <select  name="year" class="form-control form-select" autocomplete="off" />
                      <option value="1">NONE</option>
                      <?php
                      $sql = "SELECT distinct year from placed";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['year']); ?>"><?php echo htmlentities($data['year']);?></option>
                      <?php } ?>
                      </select>
                </div>
                <div class="col-sm-12 col-md-2 col-12">
                  <label>click to download.</label>
                  <button type="submit" name="submit3" class="btn btn-primary form-submit">Download</button>
                </div>
              </div> 
            </form>
        </div>
      </div>
    </div>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>