<?php  
include "../includes/config.php";
if(isset($_POST["submit2"]))  
 {    
      $branch_id = $_POST['branch'];
      $year = $_POST['year'];
      $round_id = $_POST['round'];
      $company_id = $_POST['company'];
/*--------------------------------------------------------------------------------------------------------------------*/
/*                                              begining of round wise report printing                                */
/*--------------------------------------------------------------------------------------------------------------------*/

      function roundwise($round_id,$conn){

          $filename = "round_".$round_id."_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name', 'Company','Round Name','Year',));  
          $query = "SELECT DISTINCT U.usn,U.student_name,c.company_name,r.round_name,c.year
                    from (SELECT s.usn,s.student_name,T.company_id,T.round_id
                    FROM student as s,(SELECT DISTINCT s.usn,s.company_id,s.round_id
                    FROM student_eligible_round_details as s
                    WHERE s.round_id='$round_id' and s.status='passed') as T
                    WHERE s.usn=T.usn) as U,company as c,round as r
                    WHERE U.company_id=c.company_id and U.round_id=r.round_id;";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'], $row['company_name'], $row['round_name'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);
      }

      function roundWithBranch($round_id,$branch_id,$conn){##

          $filename = "round_".$round_id . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name', 'Company','Round Name','Year',));  
          $query = "SELECT DISTINCT U.usn,U.student_name,b.branch_name,c.company_name,r.round_name,c.year
                    from (SELECT s.usn,s.student_name,T.company_id,T.round_id,s.branch_id
                    FROM student as s,(SELECT DISTINCT s.usn,s.company_id,s.round_id
                    FROM student_eligible_round_details as s
                    WHERE s.round_id='$round_id' and s.status='passed') as T
                    WHERE s.usn=T.usn and s.branch_id='$branch_id') as U,company as c,round as r,branch as b
                    WHERE U.company_id=c.company_id and U.round_id=r.round_id and U.branch_id=b.branch_id;";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'], $row['company_name'], $row['round_name'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);
      }

      function roundWithCompany($round_id,$company_id,$conn){

          $filename = "round_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name', 'Company','Round Name','Year',));  
          $query = "SELECT DISTINCT U.usn,U.student_name,b.branch_name,c.company_name,r.round_name,c.year
                    from (SELECT s.usn,s.student_name,T.company_id,T.round_id,s.branch_id
                    FROM student as s,(SELECT DISTINCT s.usn,s.company_id,s.round_id
                    FROM student_eligible_round_details as s
                    WHERE s.round_id='$round_id' and s.company_id='$company_id' and s.status='passed') as T
                    WHERE s.usn=T.usn) as U,company as c,round as r,branch as b
                    WHERE U.company_id=c.company_id and U.round_id=r.round_id and U.branch_id=b.branch_id;";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'], $row['company_name'], $row['round_name'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);

      }

      function roundWithYear($round_id,$year,$conn){

          $filename = "round_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name','Branch','Company','Round Name','Year',));  
          $query = "SELECT DISTINCT U.usn,U.student_name,b.branch_name,c.company_name,r.round_name,c.year
                    from (SELECT s.usn,s.student_name,T.company_id,T.round_id,s.branch_id
                    FROM student as s,(SELECT DISTINCT s.usn,s.company_id,s.round_id
                    FROM student_eligible_round_details as s
                    WHERE s.round_id='$round_id' and s.status='passed') as T
                    WHERE s.usn=T.usn) as U,company as c,round as r,branch as b
                    WHERE U.company_id=c.company_id and U.round_id=r.round_id and U.branch_id=b.branch_id and c.year='$year';";   
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'],$row['branch_name'],$row['company_name'], $row['round_name'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);
      }
      function roundWithBranchandCompany($round_id,$branch_id,$company_id,$conn){##

          $filename = "round_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name','Branch','Company','Round Name','Year',));  
          $query = "SELECT DISTINCT U.usn,U.student_name,b.branch_name,c.company_name,r.round_name,c.year
                    from (SELECT s.usn,s.student_name,T.company_id,T.round_id,s.branch_id
                    FROM student as s,(SELECT DISTINCT s.usn,s.company_id,s.round_id
                    FROM student_eligible_round_details as s
                    WHERE s.round_id='$round_id' and s.company_id='$company_id' and s.status='passed') as T
                    WHERE s.usn=T.usn and s.branch_id='$branch_id') as U,company as c,round as r,branch as b
                    WHERE U.company_id=c.company_id and U.round_id=r.round_id and U.branch_id=b.branch_id;";   
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'],$row['branch_name'],$row['company_name'], $row['round_name'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);
      }
/*--------------------------------------------------------------------------------------------------------------------*/
/*                                              end of round wise report printing                                     */
/*--------------------------------------------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------------------------------------------*/
/*                                      begining of eligible list report printing                                     */
/*--------------------------------------------------------------------------------------------------------------------*/

      function eligible_list_company($company_id,$conn){

          $filename = "eligible_".$company_id."_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name','Branch', 'Company','Year',));  
          $query = "SELECT DISTINCT U.usn,U.student_name,b.branch_name,c.company_name,c.year
                    from (SELECT s.usn,s.student_name,T.company_id,T.round_id,s.branch_id
                    FROM student as s,(SELECT DISTINCT s.usn,s.company_id,s.round_id
                    FROM student_eligible_round_details as s
                    WHERE s.company_id='$company_id') as T
                    WHERE s.usn=T.usn) as U,company as c,branch as b
                    WHERE U.company_id=c.company_id and U.branch_id=b.branch_id;";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'],$row['branch_name'], $row['company_name'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);
      }

      function eligible_list_company_branch($company_id,$branch_id,$conn){

          $filename = "eligible_".$company_id."_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name','Branch', 'Company','Year',));  
          $query = "SELECT DISTINCT U.usn,U.student_name,b.branch_name,c.company_name,c.year
                    from (SELECT s.usn,s.student_name,T.company_id,T.round_id,s.branch_id
                    FROM student as s,(SELECT DISTINCT s.usn,s.company_id,s.round_id
                    FROM student_eligible_round_details as s
                    WHERE s.company_id='$company_id') as T
                    WHERE s.usn=T.usn and s.branch_id='$branch_id') as U,company as c,branch as b
                    WHERE U.company_id=c.company_id and U.branch_id=b.branch_id;";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'],$row['branch_name'], $row['company_name'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);
      }

/*--------------------------------------------------------------------------------------------------------------------*/
/*                                      end of eligible list report printing                                          */
/*--------------------------------------------------------------------------------------------------------------------*/

       # begin for round wise details
      if($branch_id=="0" && $year=="1" && $round_id=="1" && $company_id=="0")
        echo"all fields are empty";

      if($branch_id=="0" && $year=="1" && $round_id!="1" && $company_id=="0")
        roundwise($round_id,$conn);

      if($branch_id=="0" && $year=="1" && $round_id!="1" && $company_id!="0")
        roundWithCompany($round_id,$company_id,$conn);

      if($branch_id!="0" && $year=="1" && $round_id!="1" && $company_id!="0")
        roundWithBranchandCompany($round_id,$branch_id,$company_id,$conn);

      if($branch_id!="0" && $year=="1" && $round_id!="1" && $company_id=="0")
        roundWithBranch($round_id,$branch_id,$conn);

      if($branch_id=="0" && $year!="1" && $round_id!="1" && $company_id=="0")
        roundWithYear($round_id,$year,$conn);
      # end of round wise information

      #begin of eligible list creation
      if($company_id!="0" && $round_id=="1" && $branch_id=="0" && $year=="1")
        eligible_list_company($company_id,$conn);

      if($company_id!="0" && $round_id=="1" && $branch_id!="0" && $year=="1")
        eligible_list_company_branch($company_id,$branch_id,$conn);
 }

/* -------------------------- PLACEMENT REPORT GENERATION ------------------- */ 

if(isset($_POST['submit'])){

      $branch_name = $_POST['branch'];
      $year = $_POST['year'];
      $company_name = $_POST['company'];

      function placed($conn){
          $filename = "placed_all_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name','Branch','Email','Company','Job','Salary','Year',));  
          $query = "SELECT * from placed";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'],$row['branch_name'],$row['student_email'], $row['company_name'], $row['job_name'],$row['job_salary'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);       

      }

      function placed_branch($branch_name,$conn){

          $filename = "placed_all_branchwise_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name','Branch','Email','Company','Job','Salary','Year',));  
          $query = "SELECT * from placed where branch_name ='$branch_name'";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'],$row['branch_name'],$row['student_email'], $row['company_name'], $row['job_name'],$row['job_salary'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);       

      }

      function placed_year($year,$conn){

          $filename = "placed_all_yearwise_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name','Branch','Email','Company','Job','Salary','Year',));  
          $query = "SELECT * from placed where year = '$year'";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'],$row['branch_name'],$row['student_email'], $row['company_name'], $row['job_name'],$row['job_salary'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);       

      }

      function placed_company($company_name,$conn){

          $filename = "placed_company_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name','Branch','Email','Company','Job','Salary','Year',));  
          $query = "SELECT * from placed where company_name = '$company_name'";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'],$row['branch_name'],$row['student_email'], $row['company_name'], $row['job_name'],$row['job_salary'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output); 
      }

      function placed_company_branch($company_name,$branch_name,$conn){

          $filename = "placed_company_branchwise_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('USN', 'Name','Branch','Email','Company','Job','Salary','Year',));  
          $query = "SELECT * from placed where company_name = '$company_name' and branch_name='$branch_name'";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['usn'],$row['student_name'],$row['branch_name'],$row['student_email'], $row['company_name'], $row['job_name'],$row['job_salary'], $row['year']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output); 
      }

      if($company_name=="0" && $branch_name=="0" && $year=="1")
        placed($conn);

      if($company_name=="0" && $branch_name!="0" && $year=="1")
        placed_branch($branch_name,$conn);

      if($company_name=="0" && $branch_name=="0" && $year!="1")
        placed_year($year,$conn);

      if($company_name!="0" && $branch_name=="0" && $year=="1")
        placed_company($company_name,$conn);

      if($company_name!="0" && $branch_name!="0" && $year=="1")
        placed_company_branch($company_name,$branch_name,$conn);

 }

 /*------------------------------PLACEMENT STATISTICS REPORT----------------------------------------*/

 if(isset($_POST['submit3'])){

      $branch_name = $_POST['branch'];
      $year = $_POST['year'];

      function placement_stat($year,$conn){
          $filename = "num_of_offers_yr_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('Company','Offers'));  
          $query = "SELECT p.company_name,COUNT(*) as no_of_offers,p.year
                    FROM placed as p
                    where p.year = '$year'
                    GROUP BY p.company_name;";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['company_name'],$row['no_of_offers']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);       

      }

      function placement_stat_branch($branch_name,$year,$conn){

          $filename = "numb_of_offers_br_" . date('Y-m-d') . ".csv";
          header('Content-Type: text/csv; charset=utf-8');  
          header('Content-Disposition: attachment; filename="' . $filename . '";');  
          $output = fopen("php://output", "w");  
          fputcsv($output, array('Company','Offers'));  
          $query = "SELECT T.company_name,COUNT(*) as no_of_offers,T.year
                    FROM (SELECT p.company_name,p.year
                    FROM placed as p
                    WHERE p.branch_name='$branch_name' and p.year = '$year') as T
                    GROUP BY T.company_name;";  
          $result = mysqli_query($conn, $query);  
          while($row = mysqli_fetch_assoc($result))  
          {  
               $lineData = array($row['company_name'],$row['no_of_offers']); 
               fputcsv($output, $lineData);  
          }  
          fclose($output);       

      }

      if($branch_name=="0" && $year!="0")
        placement_stat($year,$conn);

      if($branch_name!="0" && $year!="0")
        placement_stat_branch($branch_name,$year,$conn);

 }
 ?>