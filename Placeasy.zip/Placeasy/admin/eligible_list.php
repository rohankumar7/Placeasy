<?php              
include"../includes/config.php";
session_start();
error_reporting(0);
if(strlen($_SESSION['username'])== ""){
  header("Location:login.php");
}
if(isset($_GET['company_id'])){
    $cid=intval($_GET['company_id']);
    $query="SELECT c.backlog,c.diploma,c.girls_only FROM company as c where company_id='$cid'";
    $result=mysqli_query($conn,$query);
    $data = mysqli_fetch_assoc($result);
    $backlog = $data['backlog'];
    $diploma =$data['diploma'];
    $girls_only = $data['girls_only'];
    if($girls_only=="yes"){
        if($backlog == "yes" and $diploma == "yes"){
            $sql = "INSERT INTO student_eligible_round_details (usn,company_id,round_id) 
            SELECT q.usn,q.company_id,q.round_id FROM
            (SELECT X.usn,X.company_id,X.round_id FROM student as z,
                (select usn,company_id,round_id,year
                    from (select T.usn,T.company_id,r.round_id,T.year 
                          from round as r NATURAL JOIN
                          (select a.usn,c.company_id,c.company_name,c.year 
                           from student_academic as a,company as c 
                           where a.marks_10 >= c.prereq_10 and a.marks_12 >= c.prereq_12 and a.cgpa >= c.prereq_cgpa 
                           and c.company_id='$cid'
                          ) as T) AS R) as X
                          where z.usn = X.usn and z.placement_year = X.year and z.gender='female') as q
                          where q.usn IN 
                          (SELECT student.usn 
                            from student
                            where branch_id 
                            IN(
                            select branch.branch_id
                            from branch,company_branch
                            WHERE branch.branch_name = company_branch.branch_name 
                            and company_id='$cid'))";


    }elseif($backlog == "no" and $diploma == "yes"){
        $sql="INSERT INTO student_eligible_round_details(usn,company_id,round_id)
              SELECT q.usn,q.company_id,q.round_id FROM 
              (SELECT X.usn,X.company_id,X.round_id FROM student as z,
              (select usn,company_id,round_id,year
              from (select T.usn,T.company_id,r.round_id,T.year from round as r NATURAL JOIN
              (select a.usn,c.company_id,c.company_name,c.year 
                from student_academic as a,company as c 
                where a.marks_10 >= c.prereq_10 and a.marks_12 >= c.prereq_12 and a.cgpa >= c.prereq_cgpa and c.company_id='$cid' and a.backlog=0) as T) AS R) as X
                  where z.usn = X.usn and z.placement_year = X.year and z.gender='female') as q
                  where q.usn IN 
                          (SELECT student.usn 
                            from student
                            where branch_id 
                            IN(
                            select branch.branch_id
                            from branch,company_branch
                            WHERE branch.branch_name = company_branch.branch_name 
                            and company_id='$cid'))";
    }elseif($backlog == "yes" and $diploma == "no"){

          $sql="INSERT INTO student_eligible_round_details(usn,company_id,round_id)
              SELECT q.usn,q.company_id,q.round_id FROM 
              (SELECT X.usn,X.company_id,X.round_id FROM student as z,
              (select R.usn,R.company_id,R.round_id,R.year
              from student as s NATURAL JOIN
               (select T.usn,T.company_id,r.round_id,T.year from round as r NATURAL JOIN
              (select a.usn,c.company_id,c.company_name,c.year 
                from student_academic as a,company as c 
                where a.marks_10 >= c.prereq_10 and a.marks_12 >= c.prereq_12 and a.cgpa >= c.prereq_cgpa and c.company_id='$cid'
                ) as T) AS R
                  where s.category='engineering') as X
                  where z.usn = X.usn and z.placement_year = X.year and z.gender='female') as q
                  where q.usn IN 
                          (SELECT student.usn 
                            from student
                            where branch_id 
                            IN(
                            select branch.branch_id
                            from branch,company_branch
                            WHERE branch.branch_name = company_branch.branch_name 
                            and company_id='$cid'))";
    }else {
          $sql="INSERT INTO student_eligible_round_details(usn,company_id,round_id)
              SELECT q.usn,q.company_id,q.round_id FROM 
              (SELECT X.usn,X.company_id,X.round_id FROM student as z,
              (select usn,company_id,round_id,year
              from student as s NATURAL JOIN
               (select T.usn,T.company_id,r.round_id,T.year 
               from round as r NATURAL JOIN
              (select a.usn,c.company_id,c.company_name,c.year 
                from student_academic as a,company as c 
                where a.marks_10 >= c.prereq_10 and a.marks_12 >= c.prereq_12 and a.cgpa >= c.prereq_cgpa 
                and c.company_id='$cid' 
                and a.backlog=0) as T) AS R where s.category='engineering') as X
                where z.usn = X.usn and z.placement_year = X.year and z.gender='female') as q
                where q.usn IN 
                          (SELECT student.usn 
                            from student
                            where branch_id 
                            IN(
                            select branch.branch_id
                            from branch,company_branch
                            WHERE branch.branch_name = company_branch.branch_name 
                            and company_id='$cid'))";
    }

    }else{
    if($backlog == "yes" and $diploma == "yes"){
    $sql = "INSERT INTO student_eligible_round_details (usn,company_id,round_id) 
            SELECT q.usn,q.company_id,q.round_id FROM
            (SELECT X.usn,X.company_id,X.round_id FROM student as z,
                (select usn,company_id,round_id,year
                    from (select T.usn,T.company_id,r.round_id,T.year 
                          from round as r NATURAL JOIN
                          (select a.usn,c.company_id,c.company_name,c.year 
                           from student_academic as a,company as c 
                           where a.marks_10 >= c.prereq_10 and a.marks_12 >= c.prereq_12 and a.cgpa >= c.prereq_cgpa 
                           and c.company_id='$cid'
                          ) as T) AS R) as X
                          where z.usn = X.usn and z.placement_year = X.year) as q
                          where q.usn IN 
                          (SELECT student.usn 
                            from student
                            where branch_id 
                            IN(
                            select branch.branch_id
                            from branch,company_branch
                            WHERE branch.branch_name = company_branch.branch_name 
                            and company_id='$cid'))";


    }elseif($backlog == "no" and $diploma == "yes"){
        $sql="INSERT INTO student_eligible_round_details(usn,company_id,round_id)
              SELECT q.usn,q.company_id,q.round_id FROM 
              (SELECT X.usn,X.company_id,X.round_id FROM student as z,
              (select usn,company_id,round_id,year
              from (select T.usn,T.company_id,r.round_id,T.year from round as r NATURAL JOIN
              (select a.usn,c.company_id,c.company_name,c.year 
                from student_academic as a,company as c 
                where a.marks_10 >= c.prereq_10 and a.marks_12 >= c.prereq_12 and a.cgpa >= c.prereq_cgpa and c.company_id='$cid' and a.backlog=0) as T) AS R) as X
                  where z.usn = X.usn and z.placement_year = X.year) as q
                  where q.usn IN 
                          (SELECT student.usn 
                            from student
                            where branch_id 
                            IN(
                            select branch.branch_id
                            from branch,company_branch
                            WHERE branch.branch_name = company_branch.branch_name 
                            and company_id='$cid'))";
    }elseif($backlog == "yes" and $diploma == "no"){

          $sql="INSERT INTO student_eligible_round_details(usn,company_id,round_id)
              SELECT q.usn,q.company_id,q.round_id FROM 
              (SELECT X.usn,X.company_id,X.round_id FROM student as z,
              (select R.usn,R.company_id,R.round_id,R.year
              from student as s NATURAL JOIN
               (select T.usn,T.company_id,r.round_id,T.year from round as r NATURAL JOIN
              (select a.usn,c.company_id,c.company_name,c.year 
                from student_academic as a,company as c 
                where a.marks_10 >= c.prereq_10 and a.marks_12 >= c.prereq_12 and a.cgpa >= c.prereq_cgpa and c.company_id='$cid'
                ) as T) AS R
                  where s.category='engineering') as X
                  where z.usn = X.usn and z.placement_year = X.year) as q
                  where q.usn IN 
                          (SELECT student.usn 
                            from student
                            where branch_id 
                            IN(
                            select branch.branch_id
                            from branch,company_branch
                            WHERE branch.branch_name = company_branch.branch_name 
                            and company_id='$cid'))";
    }else {
          $sql="INSERT INTO student_eligible_round_details(usn,company_id,round_id)
              SELECT q.usn,q.company_id,q.round_id FROM 
              (SELECT X.usn,X.company_id,X.round_id FROM student as z,
              (select usn,company_id,round_id,year
              from student as s NATURAL JOIN
               (select T.usn,T.company_id,r.round_id,T.year 
               from round as r NATURAL JOIN
              (select a.usn,c.company_id,c.company_name,c.year 
                from student_academic as a,company as c 
                where a.marks_10 >= c.prereq_10 and a.marks_12 >= c.prereq_12 and a.cgpa >= c.prereq_cgpa 
                and c.company_id='$cid' 
                and a.backlog=0) as T) AS R where s.category='engineering') as X
                where z.usn = X.usn and z.placement_year = X.year) as q
                where q.usn IN 
                          (SELECT student.usn 
                            from student
                            where branch_id 
                            IN(
                            select branch.branch_id
                            from branch,company_branch
                            WHERE branch.branch_name = company_branch.branch_name 
                            and company_id='$cid'))";
    }
  }
    $results = mysqli_query($conn,$sql);
    if($results){
      $succ = "Successfully entered eligible students in database.\nClick on \"Company Name\" to Conduct Placement.";
    }
    else{
      $err = "Cannot enter eligible students. Please try again";
    }
  }
?>
<?php
if (isset($_GET['c_id'])) {
   $cid = intval($_GET['c_id']);
   $sql = "select company_name from company where company_id='$cid'";
   $res = mysqli_query($conn,$sql);
   $data = mysqli_fetch_assoc($res);
   $company = $data['company_name'];
   $msg = "Hi you are eligible for placement\nin $company";
   $sql1 = "INSERT into notification (usn,company_name,notification_text) 
              select DISTINCT B.usn,B.company_name,'$msg'
               from student as x, 
              (select usn,company_name,year
              from company natural join
              (select DISTINCT usn, company_id
               FROM student_eligible_round_details
                WHERE company_id='$cid') as C) as B
                where x.placement_year = B.year and B.usn = x.usn;";
   $result = mysqli_query($conn,$sql1);
   if($result){
    $succ = "notification sent successfully.";
   }
   else{
    $err="notification already sent / problem in sending notification.try again!";
   }
}
?>
<?php
if (isset($_GET['delid'])) {
   $cid = intval($_GET['delid']);
   $sql = "delete from student_eligible_round_details where company_id='$cid'";
   $result = mysqli_query($conn,$sql);
   if($result){
    $succ = "deleted successfully.";
   }
   else{
    $err="problem in deleting.try again!";
   }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <title>Admin | Conduct Rounds</title>
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="admin_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.css"/>

  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9733EE;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
    <?php include "../includes/navbar_admin.php"; ?>
<div class="container" style="margin-top: 100px">
                    <?php
                    if ($err) {?>
                          <div class="error wow fadeInLeft animated"><?php echo htmlentities($err); ?></div>
                  <?php } else if($succ) { ?>
                          <div class="success wow fadeInLeft animated"><?php echo htmlentities($succ); ?></div>
                  <?php }
                    ?>
<div class="table-responsive-sm">
          <table id="myTable" class="display">
            <thead>
              <tr>
                <th>No.</th>
                <th>Company ID</th>
                <th>Company Name</th>
                <th>Year</th>
                <th>Eligible list</th>
                <th>Delete Eligible List</th>
                <th>Notify</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $sql = "SELECT company_id,company_name,year
                      from company";
              $res=mysqli_query($conn,$sql);
              $cnt=1;
              while($d = mysqli_fetch_assoc($res)){?>
              <tr>
                <td><?php echo htmlentities($cnt); ?></td>
                <td><?php echo htmlentities($d['company_id']); ?></td>
                <td><a href="conduct_round.php?company_id=<?php echo htmlentities($d['company_id']);?>" class="info purple"><?php echo htmlentities($d['company_name']); ?></a></td>
                <td><?php echo htmlentities($d['year']); ?></td>

                <td><a href="eligible_list.php?company_id=<?php echo htmlentities($d['company_id']);?>"><button class="btn btn-outline-secondary">Create Eligible List</button></a></td>
                <td><a href="eligible_list.php?delid=<?php echo htmlentities($d['company_id']);?>"><button class="btn btn-outline-secondary">Delete Eligible List</button></a></td>

                <td><a href="eligible_list.php?c_id=<?php echo htmlentities($d['company_id']);?>"><button class="btn btn-outline-secondary">notify students</button></a></td>
              </tr>
            <?php $cnt++; ?>
            <?php } ?>
            </tbody>
          </table>
    </div>
</div>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.js"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>
<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>