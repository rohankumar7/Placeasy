<?php
include "../includes/config.php";
	if(isset($_POST['submitpdf'])){
	$year = $_POST['year'];
	$sql = "SELECT count(*) as no_of_company from company where year ='$year'";
	$res = mysqli_query($conn,$sql);
	$data = mysqli_fetch_assoc($res);
	$company = $data['no_of_company'];

	//number of eligible students
	$year1 = explode("-",$year);
	$year2 = current($year1);
	$sql1 = "SELECT COUNT(*) as eligible
	FROM (SELECT s.usn,s.company_id,COUNT(*)
	FROM student_eligible_round_details as s
	where date_of_conduct LIKE '$year2%'
	GROUP BY s.usn,s.company_id) as T";
	$res1 = mysqli_query($conn,$sql1);
	$data1 = mysqli_fetch_assoc($res1);
	$eligible = $data1['eligible'];

	//number of students placed

	$sql2 = "SELECT count(*) as no_of_placed 
             FROM
			(SELECT COUNT(*)
			FROM placed as s
             where s.year='$year'
			GROUP BY s.student_name
            ) as T;";
	$res2 = mysqli_query($conn,$sql2);
	$data2 = mysqli_fetch_assoc($res2);
	$placed = $data2['no_of_placed'];

	//number of student multiple got offers 

	$sql3 = "SELECT count(*) as multiple from
		(SELECT usn,count(*)
		from placed
		where year='$year'
		group by usn
		HAVING count(*) >1) as t;";
	$res3 = mysqli_query($conn,$sql3);
	$data3 = mysqli_fetch_assoc($res3);
	$multiple = $data3['multiple'];
}
?>
<?php
//call the FPDF library
require('../fpdf/fpdf.php');

//A4 width : 219mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm
	//create pdf object
$pdf = new FPDF('P','mm','A4');
//add new page
$pdf->AddPage();
//set font to arial, bold, 14pt
$pdf->SetFont('Arial','B',20);
$image1 = "../SDM_Logo.png";
$pdf->Cell(189,10,'',0,1);

//Cell(width , height , text , border , end line , [align] )
$pdf->Cell( 40, 40, $pdf->Image($image1, $pdf->GetX(), $pdf->GetY(), 15), 0, 0, 'L', false );
$pdf->setX(30);
$pdf->Cell(130 ,10,'SDM Colllege of Engineering and Technology',0,1);
$pdf->setX(70);
$pdf->Cell(130 ,10,'Dharwad - 580002',0,1);

$pdf->Cell(189,30,'',0,1);

$pdf->SetFont('Arial','B',14);

$pdf->Cell(130 ,15,'Description',1,0,'C');
$pdf->Cell(59 ,15,'Result',1,1,'C');
$pdf->SetFont('Arial','',12);

$pdf->Cell(130 ,8,'Academic Year',1,0);
$pdf->Cell(59 ,8,$year,1,1,'R');

$pdf->Cell(130 ,8,'Number of company visited',1,0);
$pdf->Cell(59 ,8,$company,1,1,'R');

$pdf->Cell(130 ,8,'Number of student eligible',1,0);
$pdf->Cell(59 ,8,$eligible,1,1,'R');

$pdf->Cell(130 ,8,'Number of student placed',1,0);
$pdf->Cell(59 ,8,$placed,1,1,'R');

$pdf->Cell(130 ,8,'Number of student got Multiple Offers',1,0);
$pdf->Cell(59 ,8,$multiple,1,1,'R');

$pdf->Output();
?>
