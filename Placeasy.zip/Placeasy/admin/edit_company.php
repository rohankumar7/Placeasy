<?php
include "../includes/config.php";
session_start();
error_reporting(0);
if(strlen($_SESSION['username'])== ""){
  header("Location:login.php");
}
else{
  if(isset($_POST['edit_company'])){
    $company_name=$_POST['c_name'];
    $company_id=intval($_GET['company_id']);
    $prereq_10=$_POST['prereq_10'];
    $prereq_12=$_POST['prereq_12'];
    $prereq_cgpa=$_POST['prereq_cgpa'];
    $year2 = $_POST['year'];
    $backlog = $_POST['backlog'];
    $diploma = $_POST['diploma'];
    $girls_only = $_POST['girls_only'];
    if($girls_only==""){
      $girls_only = "no";
    }
    $sql="UPDATE company 
    SET company_id='$company_id',
    backlog='$backlog',
    girls_only='$girls_only',
    diploma='$diploma',
    company_name='$company_name',
    prereq_10='$prereq_10',
    prereq_12='$prereq_12',
    prereq_cgpa ='$prereq_cgpa',
    year='$year2'
    WHERE company_id='$company_id'";
      $result=mysqli_query($conn,$sql);
      if($result){
        $succ="Successfully updated company details";
      }
      else{
        $err="Something went Wrong ! Try again later";
      }
  }
}  
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
     <meta charset="utf-8">
     <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="admin_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9733EE;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>
    <title>Admin | Edit Company</title>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
        <?php include "../includes/navbar_admin.php"; ?>
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-12 col-sm-12  offset-md-3 form-panel wow fadeInLeft animated">
          <!--<a href="#" class="back-btn"><i class="fas fa-arrow-left"></i></a>-->
          <h2 class="form-header"><i class="far fa-user"></i> Update Company Details.</h2>
            <form method="post">
              <div class="row">
                <div class="col-sm-12 col-md-12 col-12">
                  <?php
                    if ($err) {?>
                          <div class="error wow fadeInLeft animated"><?php echo htmlentities($err); ?></div>
                  <?php } else if($succ) { ?>
                          <div class="success wow fadeInLeft animated"><?php echo htmlentities($succ); ?></div>
                  <?php }
                    ?>
                  <?php
                    $company_id=intval($_GET['company_id']);
                    $sql="SELECT * from company where company.company_id='$company_id'";
                    $result=mysqli_query($conn,$sql);
                    if($result){
                      while($data=mysqli_fetch_assoc($result)){ ?>
                      <div class="form-row">
                    <div class="form-group col-12">
                      <label class="info">Comapany Name</label>
                      <input type="text" class="form-control form-input special" name="c_name" placeholder="Company Name" value="<?php echo htmlentities($data['company_name'])?>" required/>
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="form-group col-sm-6 col-md-6 col-6">
                      <label class="info">Comapany ID</label>
                      <input type="text" class="form-control form-input special" name="c_id" placeholder="Company ID" value="<?php echo htmlentities($data['company_id']); ?>" disabled required/>
                    </div>
                    <div class="form-group col-6 col-md-6 col-sm-6">
                      <label class="info">Year of visit</label>
                      <input type="text" class="form-control form-input special" name="year" placeholder="Year of visit" value="<?php echo htmlentities($data['year']);?>" required/>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-check">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" required name="backlog" value="yes"><span class="info">Backlog Allowed</span>
                      </label>
                    </div>
                    <div class="form-check" style="margin-left: 20px">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="backlog" value="no"><span class="info">Backlog Not Allowed</span>
                      </label>
                    </div><span class="info purple" style="margin-left: 30px;">( <?php echo htmlentities($data['backlog']);?> )</span>
                  </div>
                  <div class="form-row">
                    <div class="form-check">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="diploma" required value="yes"><span class="info">Diploma Allowed</span>
                      </label>
                    </div>
                    <div class="form-check" style="margin-left: 20px">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="diploma" value="no"><span class="info">Diploma Not Allowed</span>
                      </label>
                    </div><span class="info purple" style="margin-left: 30px;">( <?php echo htmlentities($data['diploma']);?> )</span>
                  </div>
                  <div class="form-row">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="girls_only" value="yes" id="defaultCheck1">
                      <label class="form-check-label" for="defaultCheck1">
                        <span class="info">Girls only</span>
                      </label>
                    </div><span class="info purple" style="margin-left: 30px;">( <?php echo htmlentities($data['girls_only']);?> )</span>
                  </div>
                  <hr>
                  <div class="form-row">
                    <div class="form-group col-4 col-sm-4 col-md-4">
                      <label class="info">10th Board</label>
                      <input type="text" class="form-control form-input special" name="prereq_10" placeholder="10th Board" value="<?php echo htmlentities($data['prereq_10']);?>" required/>
                    </div>
                    <div class="form-group col-4 col-sm-4 col-md-4">
                      <label class="info">12th Board</label>
                      <input type="text" class="form-control form-input special" name="prereq_12" placeholder="12th Board" value="<?php echo htmlentities($data['prereq_12']);?>" required/>
                    </div>
                    <div class="form-group col-4 col-sm-4 col-md-4">
                      <label class="info">cgpa</label>
                      <input type="text" class="form-control form-input special" name="prereq_cgpa" placeholder="CGPA" value="<?php echo htmlentities($data['prereq_cgpa']);?>" required/>
                    </div>
                  </div>
                  <button type="submit" name="edit_company" id="inp" class="btn btn-primary form-submit">Update</button>
                    <?php  }
                    } ?>
                  
                </div>
              </div> 
            </form>
        </div>
      </div>
    </div>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>