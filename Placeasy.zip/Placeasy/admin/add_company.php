<?php
include "../includes/config.php";
session_start();
error_reporting(0);
$y = date('y');
$y1 = date('y') +1;
$year = "20".$y."-"."20".$y1;
if(strlen($_SESSION['username'])== ""){
  header("Location:login.php");
}
else{
  if(isset($_POST['add_company'])){
  $company_id=$_POST['c_id'];
  $company_name=$_POST['c_name'];
  $prereq_10=$_POST['board10'];
  $prereq_12=$_POST['board12'];
  $cgpa=$_POST['cgpa'];
  $year2 = $_POST['year'];
  $backlog = $_POST['backlog'];
  $diploma = $_POST['diploma'];
  $girls_only = $_POST['girls_only'];
      if($girls_only==""){
      $girls_only = "no";
    }
  $sql="INSERT INTO company(company_id,company_name,prereq_10,prereq_12,prereq_cgpa,year,backlog,diploma,girls_only) values ('$company_id','$company_name','$prereq_10','$prereq_12','$cgpa','$year2','$backlog','$diploma','$girls_only')";
  $result=mysqli_query($conn,$sql);
  if ($result) {
    $succ="Successfully added Company!"; 
  }
  else{
    $err="Something went wrong, please try again!";
  }
}
}  
?>
<?php
  if (isset($_GET['del'])) {
    $id = $_GET['company_id'];
    $sql = "DELETE from company where company_id='$id'";
    $results = mysqli_query($conn,$sql);
    if($results){
      $succ = "Successfully deleted Company.";
    }
    else{
      $err = "Cannot delete Company. Please try again";
    }
  }
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="admin_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.css"/>
    <script src="./../js/wow.min.js"></script>
  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9733EE;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      } 
  </style>
    <title>Admin | Add Company</title>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
    <?php include "../includes/navbar_admin.php"; ?>
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-12 col-sm-12 form-panel wow fadeInLeft animated">
          <!--<a href="#" class="back-btn"><i class="fas fa-arrow-left"></i></a>-->
          <h2 class="form-header"><i class="far fa-user"></i> Add Company Details.</h2>
              <div class="row">
                <div class="col-sm-12 col-md-12 col-12">
                  <form method="post">
                  <?php
                    if ($err) {?>
                          <div class="error wow fadeInLeft animated"><?php echo htmlentities($err); ?></div>
                  <?php } else if($succ) { ?>
                          <div class="success wow fadeInLeft animated"><?php echo htmlentities($succ); ?></div>
                  <?php }
                    ?>
                  <div class="form-row">
                    <div class="form-group col-sm-6 col-md-6 col-12">
                      <input type="text" class="form-control form-input special" name="c_name" placeholder="Company Name" required/>
                    </div>
                    <div class="form-group col-sm-6 col-md-3 col-12">
                      <input type="text" class="form-control form-input special" name="c_id" placeholder="Company ID" required/>
                    </div>
                    <div class="form-group col-sm-6 col-md-3 col-12">
                      <input type="text" class="form-control form-input special" value="<?php echo($year); ?>" name="year" placeholder="Year of visit" required/>
                    </div>
                  </div>
                  <p class="info">Company requirements.</p>
                  <div class="form-row">
                    <div class="form-group col-12 col-sm-6 col-md-3">
                      <input type="text" class="form-control form-input special" name="board10" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." placeholder="10th Board" required/>
                    </div>
                    <div class="form-group col-12 col-sm-6 col-md-3">
                      <input type="text" class="form-control form-input special" name="board12" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." placeholder="12th Board" required/>
                    </div>
                   <div class="form-group col-12 col-sm-6 col-md-3">
                      <input type="text" class="form-control form-input special" name="cgpa" pattern="[+-]?([0-9]*[.])?[0-9]+" title="Please enter only decimal or float value." placeholder="CGPA" required/>
                    </div>
                    <div class="form-group col-12 col-sm-6 col-md-3">
                  <button type="submit" name="add_company" class="btn btn-primary form-submit">Add Company</button>
                    </div>
                  </div>

                  <div class="form-row">
                    
                    <div class="form-check">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="backlog" value="yes"><span class="info">Backlog Allowed</span>
                      </label>
                    </div>
                    <div class="form-check" style="margin-left: 20px">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="backlog" value="no"><span class="info">Backlog Not Allowed</span>
                      </label>
                    </div>

                    <div class="form-check">
                      <label class="form-check-label" style="margin-left: 30px">
                        <input type="radio" class="form-check-input" name="diploma" value="yes"><span class="info">Diploma Allowed</span>
                      </label>
                    </div>
                    <div class="form-check" style="margin-left: 20px">
                      <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="diploma" value="no"><span class="info">Diploma Not Allowed</span>
                      </label>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="girls_only" value="yes" id="defaultCheck1">
                      <label class="form-check-label" for="defaultCheck1">
                        <span class="info">Girls only</span>
                      </label>
                    </div>
                  </div>
                  </div>
                  </form>
                  </div>

                </div>
              </div> 
        </div>
      </div>
    </div>
<div class="container" style="margin-top: 10px">
  <hr>
<div class="table-responsive-sm">
          <table id="myTable" class="display">
            <thead>
              <tr>
                <th>Company ID</th>
                <th>Company Name</th>
                <th>10th</th>
                <th>12th/Diploma</th>
                <th>CGPA</th>
                <th>Backlog</th>
                <th>Diploma</th>
                <th>Girls Only</th>
                <th>Year</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $sql = "SELECT * from company";
              $res=mysqli_query($conn,$sql);
              $cnt=1;
              while($d = mysqli_fetch_assoc($res)){?>
              <tr>
                <td><?php echo htmlentities($d['company_id']); ?></td>
                <td><?php echo htmlentities($d['company_name']); ?></td>
                <td><?php echo htmlentities($d['prereq_10']); ?>%</td>
                <td><?php echo htmlentities($d['prereq_12']); ?>%</td>
                <td><?php echo htmlentities($d['prereq_cgpa']); ?></td>
                <td><?php echo htmlentities($d['backlog']); ?></td>
                <td><?php echo htmlentities($d['diploma']); ?></td>
                <td><?php echo htmlentities($d['girls_only']); ?></td>
                <td><?php echo htmlentities($d['year']); ?></td>
                <td><a style="color: #222" href="edit_company.php?company_id=<?php echo htmlentities($d['company_id'])?>"><i class="fas fa-edit"></i></a><span style="margin-right: 20px"></span><a onclick="return confirm('Do you want to delete');" style="color: #222" href="add_company.php?company_id=<?php echo htmlentities($d['company_id'])?>&del=true"><i class="fas fa-trash-alt"></i></a></td>
              </tr>
            <?php $cnt++; ?>
            <?php } ?>
            </tbody>
          </table>
    </div>
</div>

        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.js"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>
<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>

<script type="text/javascript">
 
    $(document).ready(function() {
 $('select').selectpicker();
    });
 
</script>