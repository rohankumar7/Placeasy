<?php
session_start();
error_reporting(0);
include"../includes/config.php";
if(strlen($_SESSION['username'])== ""){
  header("Location:login.php");
}
if(isset($_POST['filter'])){
  if($_FILES['round_file']['name']){
    $filename = explode(".",$_FILES['round_file']['name']);
    if(end($filename) == "csv"){
      $handle = fopen($_FILES['round_file']['tmp_name'], "r");

      while($data = fgetcsv($handle)){
        $usn = mysqli_real_escape_string($conn, $data[0]);
        $round_id = $_POST['rname'];
        $company_id = $_GET['company_id'];
        $sqlfail = "UPDATE student_eligible_round_details 
              set status = 'failed' 
              where company_id = '$company_id' and round_id = '$round_id' and status='pending'";
        $resfail = mysqli_query($conn,$sqlfail);
        $sql = "UPDATE student_eligible_round_details 
                set status = 'passed' 
                where usn = '$usn' and company_id = '$company_id' and round_id = '$round_id'";
        $result = mysqli_query($conn,$sql);
      }
      fclose($handle);
    }
  }
}
?>
<?php
if(isset($_POST['finish'])){
  $cid = intval($_GET['company_id']);
  $query = "SELECT j.usn,j.student_name,j.branch_name,j.email,j.company_name,job_name,job_salary,j.year 
                from job_details NATURAL join
                (select * from company NATURAL join 
                (select * from branch NATURAL join 
                (select * from student NATURAL join 
                (SELECT DISTINCT usn,company_id 
                 FROM student_eligible_round_details 
                 where company_id = '$cid' and round_id = 'HR100' and status='passed') as a) as c) as x) as j";
  $res1 = mysqli_query($conn,$query);
  $count = mysqli_num_rows($res1);
  if($count>0){                 
  $sql = "INSERT INTO placed (usn,student_name,branch_name,student_email,company_name,job_name,job_salary,year)
                SELECT j.usn,j.student_name,j.branch_name,j.email,j.company_name,job_name,job_salary,j.year 
                from job_details NATURAL join
                (select * from company NATURAL join 
                (select * from branch NATURAL join 
                (select * from student NATURAL join 
                (SELECT DISTINCT usn,company_id 
                 FROM student_eligible_round_details 
                 where company_id = '$cid' and round_id = 'HR100' and status='passed') as a) as c) as x) as j";

  $res = mysqli_query($conn,$sql);
  if($res){
    $succ = "placement completed.";
  }
  else{
    $err = "Already completed this procedure / something went wrong!";
  }
}
else{
  $err = "HR round has not conducted";
}
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <title>Admin | Conduct Rounds</title>
    <meta charset="utf-8">
    <link href="SDM_logo.png" rel="icon">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="admin_style.css">
    <link href="./../css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="./../js/wow.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.css"/>

  <script>
     new WOW().init();
  </script>

    <style type="text/css">
      .loader {
        border: 3px solid #f3f3f3;
        border-radius: 50%;
        border-top: 3px solid #9733EE;
        width: 50px;
        height: 50px;
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin:auto;
        -webkit-animation: spin .5s linear infinite; /* Safari */
        animation: spin .5s linear infinite;
      }

      /* Safari */
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      #overlay{
        height: 100%;
        width: 100%;
        background: rgba(255,255,255,1);
        z-index: 999999;
        position: fixed;
        left: 0;
        top: 0;
      }
      .mystyle{
        color:#fff;
        background-color: #f62459;
        border-radius: 5px;
        border:1px solid #f62459;
      }
  </style>  
  </head>
  <body>
    <div id="overlay">
      <div class="loader"></div>
    </div>
    <?php include "../includes/navbar_admin.php"; ?>
<div class="container" style="margin-top: 100px">
  <div class="row">
    <div class="col-md-8">
                        <?php
                    if ($err) {?>
                          <div class="error wow fadeInLeft animated"><?php echo htmlentities($err); ?></div>
                  <?php } else if($succ) { ?>
                          <div class="success wow fadeInLeft animated"><?php echo htmlentities($succ); ?></div>
                  <?php }
                    ?>
      <form method="post" enctype="multipart/form-data">
        <div class="form-row">
          <div class="form-group col-md-4">
                      <select  name="rname" class="form-control form-select" autocomplete="off"  required/>
                      <option value="">Round Name...</option>
                      <?php
                      $sql = "SELECT distinct round_id,round_name from round";
                      $result=mysqli_query($conn,$sql);
                      while($data = mysqli_fetch_assoc($result)){?>
                      <option value="<?php echo htmlentities($data['round_id']); ?>"><?php echo htmlentities($data['round_name']);?></option>
                      <?php } ?>
                      </select>
          </div>
          <div class="form-group col-md-4">
            <input type="file" name="round_file" required>
          </div>
          <div class="form-group col-md-4">
            <button type="submit" class="form-submit" name="filter">submit</button>
          </div>
        </div>
      </form>
    </div>
          <div class="col-md-2 offset-md-2">
      <form method="post">
        <input type="submit" name="finish" value="finish" class="form-submit">
      </form>
      </div>
  </div>
<div class="table-responsive-sm">
          <table class="table table-striped table-borderless" id="myTable">
            <thead>
              <tr>
                <th>Sl No.</th>
                <th>USN</th>
                <th>Student Name</th>
                <th>Category</th>
                <th>Company ID</th>
                <th>Company Name</th>
                <th>Year</th>
              </tr>
            </thead>
            <tbody id="mytable">
              <?php
              $cid= intval($_GET['company_id']);
              $sql="SELECT DISTINCT s.usn,s.student_name,s.category,c.company_name,c.year,c.company_id,r.round_id,r.round_name
                    from student as s,company as c,round as r,
                      (SELECT distinct *
                      from student_eligible_round_details
                      where company_id='$cid' group by usn) as T
                    where s.usn=T.usn and c.company_id=T.company_id and r.round_id=T.round_id order by usn asc";
              $res=mysqli_query($conn,$sql);
              $cnt=1;
              while($d = mysqli_fetch_assoc($res)){
                $usn =$d['usn']; ?>
              <tr>
                <td><?php echo $cnt; ?></td>
                <td><span class="info" style="color: #111"><?php echo htmlentities($d['usn']); ?></span></td>
                <td><span class="info" style="color: #111"><?php echo htmlentities($d['student_name']); ?></span></td>
                <td><?php echo htmlentities($d['category']); ?></td>
                <td><?php echo htmlentities($d['company_id']); ?></td>
                <td><?php echo htmlentities($d['company_name']); ?></td>
                <td><?php echo htmlentities($d['year']); ?></td>
              </tr>
              <tr>
                <?php 
                  $sql1 = "SELECT DISTINCT r.round_id,r.round_name,s.status from round as r 
                           JOIN student_eligible_round_details as s ON r.round_id = s.round_id
                           where s.company_id='$cid' and s.usn = '$usn'";
                  $res1=mysqli_query($conn,$sql1);
                  while($d1 = mysqli_fetch_assoc($res1)){?>
                    <td>
                      <span class="info"><?php echo htmlentities($d1['round_name']);?></span>
                    </a><br><span style="margin-top: 5px">
                    <?php if($d1['status'] == "passed"){?>
                    <span style="color:lime;font-weight:bold"><?php echo htmlentities($d1['status']); ?> <i class="fas fa-check"></i></span>
                    <?php }elseif($d1['status'] == "failed") { ?>
                    <span style="font-weight:bold;color:red"><?php echo htmlentities($d1['status']); ?> <i class="fas fa-times"></i></span>
                   <?php }else{?>
                    <span style="font-weight:bold;color:orange"><?php echo htmlentities($d1['status']); ?> <i class="fas fa-hourglass-end"></i></span>
                  <?php } ?>
                  </span>
                  </td>
                <?php } ?>
                
              </tr>
            <?php $cnt++; ?>
            <?php } ?>
            </tbody>
          </table>
    </div>
</div>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.js"></script>
  </body>
</html>
<script type="text/javascript">
  var overlay = document.getElementById("overlay");
  window.addEventListener("load",function(){
    overlay.style.display = 'none';
  });
</script>
<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>