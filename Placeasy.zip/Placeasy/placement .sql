-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2019 at 01:53 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `placement`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`) VALUES
(1, 'CS Engineering'),
(2, 'IS Engineering'),
(3, 'E&C Engineering'),
(4, 'E&E Engineering'),
(5, 'Civil Engineering'),
(6, 'Mechanical Engineering'),
(7, 'Chemical Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` int(11) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `prereq_10` float NOT NULL,
  `prereq_12` float NOT NULL,
  `prereq_cgpa` float NOT NULL,
  `year` varchar(15) DEFAULT NULL,
  `place` varchar(10) NOT NULL DEFAULT 'campus',
  `backlog` varchar(10) NOT NULL,
  `diploma` varchar(10) NOT NULL,
  `girls_only` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`company_id`, `company_name`, `prereq_10`, `prereq_12`, `prereq_cgpa`, `year`, `place`, `backlog`, `diploma`, `girls_only`) VALUES
(1002, 'Oracle', 75, 75, 8.2, '2019-2020', 'campus', 'yes', 'yes', 'yes'),
(1003, 'Accenture', 60, 60, 7, '2019-2020', 'campus', 'yes', 'yes', 'no'),
(1004, 'Informatica', 60, 60, 8.2, '2019-2020', 'campus', 'yes', 'yes', 'no'),
(1005, 'Dell', 60, 60, 8.2, '2019-2020', 'campus', 'yes', 'yes', 'no'),
(1006, 'Sony', 60, 65, 8, '2019-2020', 'campus', 'yes', 'yes', 'no'),
(1007, 'Global Edge', 60, 60, 8.2, '2019-2020', 'campus', 'yes', 'no', 'no'),
(1010, 'bosch', 68, 70, 8, '2019-2020', 'campus', 'no', 'no', 'no'),
(1011, 'aditya birla', 78, 45, 8, '2019-2020', 'campus', 'yes', 'yes', 'no'),
(1111, 'microfinish', 77, 89, 6, '2019-2020', 'campus', 'no', 'yes', 'no'),
(1212, 'KPIT', 68, 89, 6, '2019-2020', 'campus', 'no', 'no', 'no'),
(4554, 'indian navy', 68, 85, 6, '2019-2020', 'campus', 'no', 'yes', 'no'),
(7881, 'manglore chemicals', 68, 70, 7, '2019-2020', 'campus', 'no', 'no', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `company_branch`
--

CREATE TABLE `company_branch` (
  `company_id` int(11) NOT NULL,
  `branch_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_branch`
--

INSERT INTO `company_branch` (`company_id`, `branch_name`) VALUES
(1002, 'CS Engineering'),
(1002, 'IS Engineering'),
(1003, 'Chemical Engineering'),
(1003, 'Civil Engineering'),
(1003, 'CS Engineering'),
(1003, 'E&C Engineering'),
(1003, 'E&E Engineering'),
(1003, 'IS Engineering'),
(1003, 'Mechanical Engineering'),
(1004, 'CS Engineering'),
(1004, 'E&C Engineering'),
(1004, 'IS Engineering'),
(1005, 'IS Engineering'),
(1006, 'CS Engineering'),
(1007, 'CS Engineering'),
(1010, 'Mechanical Engineering'),
(1011, 'Chemical Engineering'),
(1011, 'Civil Engineering'),
(1011, 'CS Engineering'),
(1111, 'CS Engineering'),
(1111, 'E&C Engineering'),
(1212, 'E&C Engineering'),
(1212, 'E&E Engineering'),
(4554, 'CS Engineering'),
(4554, 'E&C Engineering'),
(4554, 'Mechanical Engineering'),
(7881, 'Chemical Engineering'),
(7881, 'Civil Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `job_details`
--

CREATE TABLE `job_details` (
  `job_id` varchar(20) NOT NULL,
  `company_id` int(11) NOT NULL,
  `job_name` varchar(20) DEFAULT NULL,
  `job_vacancy` int(11) DEFAULT NULL,
  `job_salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_details`
--

INSERT INTO `job_details` (`job_id`, `company_id`, `job_name`, `job_vacancy`, `job_salary`) VALUES
('acc100', 1003, 'Tester', 100, 380000),
('adi100', 1011, 'Tester', 0, 500000),
('bos100', 1010, 'developer', 0, 500000),
('del100', 1005, 'Tester', 5, 750000),
('gob100', 1007, 'call center', 10, 300000),
('ind100', 4554, 'maintainance', 0, 650000),
('inf100', 1004, 'Developer', 5, 66000),
('kpi100', 1212, 'Tester', 0, 250000),
('man100', 7881, 'Tester', 0, 450000),
('mic100', 1111, 'Tester', 0, 500000),
('ora100', 1002, 'Developer', 3, 800000),
('son100', 1006, 'Tester', 2, 750000);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `usn` varchar(20) NOT NULL,
  `company_name` varchar(20) NOT NULL,
  `notification_text` varchar(100) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `offcampus`
--

CREATE TABLE `offcampus` (
  `off_campus_id` int(11) NOT NULL,
  `usn` varchar(20) NOT NULL,
  `offcampus_company` varchar(30) NOT NULL,
  `offcampus_company_package` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `placed`
--

CREATE TABLE `placed` (
  `usn` varchar(20) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `branch_name` varchar(30) NOT NULL,
  `student_email` varchar(50) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `job_name` varchar(20) NOT NULL,
  `job_salary` int(11) NOT NULL,
  `year` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `placed`
--

-- --------------------------------------------------------

--
-- Table structure for table `round`
--

CREATE TABLE `round` (
  `round_id` varchar(10) NOT NULL,
  `round_name` varchar(20) NOT NULL,
  `company_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `round`
--

INSERT INTO `round` (`round_id`, `round_name`, `company_id`) VALUES
('APT100', 'Aptitude', 1002),
('APT100', 'Aptitude', 1003),
('APT100', 'Aptitude', 1004),
('APT100', 'Aptitude', 1005),
('APT100', 'Aptitude', 1006),
('APT100', 'Aptitude', 1007),
('APT100', 'Aptitude', 1010),
('APT100', 'Aptitude', 1011),
('APT100', 'Aptitude', 1111),
('APT100', 'Aptitude', 1212),
('APT100', 'Aptitude', 4554),
('APT100', 'Aptitude', 7881),
('HR100', 'HR', 1002),
('HR100', 'HR', 1003),
('HR100', 'HR', 1004),
('HR100', 'HR', 1005),
('HR100', 'HR', 1006),
('HR100', 'HR', 1007),
('HR100', 'HR', 1010),
('HR100', 'HR', 1011),
('HR100', 'HR', 1111),
('HR100', 'HR', 1212),
('HR100', 'HR', 4554),
('HR100', 'HR', 7881),
('HR200', 'HR-2', 1111),
('TH200', 'TECHNICAL-2', 4554),
('THN100', 'Technical', 1002),
('THN100', 'Technical', 1004),
('THN100', 'Technical', 1005),
('THN100', 'Technical', 1010),
('THN100', 'Technical', 1111),
('THN100', 'Technical', 1212),
('THN200', 'Technical-2', 1004);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `usn` varchar(20) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `placement_year` varchar(15) DEFAULT NULL,
  `student_phoneno` varchar(15) DEFAULT NULL,
  `category` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_academic`
--

CREATE TABLE `student_academic` (
  `usn` varchar(20) NOT NULL,
  `marks_10` float NOT NULL,
  `marks_12` float NOT NULL,
  `sem_1` float NOT NULL,
  `sem_2` float NOT NULL,
  `sem_3` float NOT NULL,
  `sem_4` float NOT NULL,
  `sem_5` float NOT NULL,
  `sem_6` float NOT NULL,
  `sem_7` float NOT NULL DEFAULT '0',
  `sem_8` float NOT NULL DEFAULT '0',
  `cgpa` float NOT NULL,
  `backlog` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_academic`
--


-- --------------------------------------------------------

--
-- Table structure for table `student_eligible_round_details`
--

CREATE TABLE `student_eligible_round_details` (
  `usn` varchar(20) NOT NULL,
  `company_id` int(11) NOT NULL,
  `round_id` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `date_of_conduct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_eligible_round_details`
--

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `company_branch`
--
ALTER TABLE `company_branch`
  ADD PRIMARY KEY (`company_id`,`branch_name`);

--
-- Indexes for table `job_details`
--
ALTER TABLE `job_details`
  ADD PRIMARY KEY (`job_id`,`company_id`),
  ADD KEY `c_j_fk` (`company_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`usn`,`company_name`);

--
-- Indexes for table `offcampus`
--
ALTER TABLE `offcampus`
  ADD PRIMARY KEY (`off_campus_id`,`usn`),
  ADD KEY `s_of_id` (`usn`);

--
-- Indexes for table `placed`
--
ALTER TABLE `placed`
  ADD PRIMARY KEY (`usn`,`company_name`);

--
-- Indexes for table `round`
--
ALTER TABLE `round`
  ADD PRIMARY KEY (`round_id`,`company_id`),
  ADD KEY `c_r_fk` (`company_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`usn`),
  ADD KEY `branch_fk` (`branch_id`);

--
-- Indexes for table `student_academic`
--
ALTER TABLE `student_academic`
  ADD PRIMARY KEY (`usn`);

--
-- Indexes for table `student_eligible_round_details`
--
ALTER TABLE `student_eligible_round_details`
  ADD PRIMARY KEY (`usn`,`company_id`,`round_id`),
  ADD KEY `c_erd_fk` (`company_id`),
  ADD KEY `r_erd_fk` (`round_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `offcampus`
--
ALTER TABLE `offcampus`
  MODIFY `off_campus_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `company_branch`
--
ALTER TABLE `company_branch`
  ADD CONSTRAINT `kf` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE CASCADE;

--
-- Constraints for table `job_details`
--
ALTER TABLE `job_details`
  ADD CONSTRAINT `c_j_fk` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE CASCADE;

--
-- Constraints for table `offcampus`
--
ALTER TABLE `offcampus`
  ADD CONSTRAINT `s_of_id` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE;

--
-- Constraints for table `placed`
--
ALTER TABLE `placed`
  ADD CONSTRAINT `s_p_fk` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE;

--
-- Constraints for table `round`
--
ALTER TABLE `round`
  ADD CONSTRAINT `c_r_fk` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `branch_fk` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`);

--
-- Constraints for table `student_academic`
--
ALTER TABLE `student_academic`
  ADD CONSTRAINT `student_id_fk` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE;

--
-- Constraints for table `student_eligible_round_details`
--
ALTER TABLE `student_eligible_round_details`
  ADD CONSTRAINT `c_erd_fk` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `r_erd_fk` FOREIGN KEY (`round_id`) REFERENCES `round` (`round_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `s_erd_fk` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
